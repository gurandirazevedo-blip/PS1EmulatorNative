package com.ps1.emulator

import android.content.ComponentCallbacks2
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import com.ps1.emulator.core.CoreInfo
import com.ps1.emulator.data.BiosManager
import com.ps1.emulator.data.Game
import com.ps1.emulator.data.Library
import com.ps1.emulator.data.Settings
import com.ps1.emulator.emu.EmulatorActivity
import com.ps1.emulator.ui.CoverCache
import com.ps1.emulator.ui.HomeScreen
import com.ps1.emulator.ui.PS1Theme
import com.ps1.emulator.ui.SettingsScreen
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PS1Theme { App() } }
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN) CoverCache.trim()
    }
}

@Composable
private fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val settings = remember { Settings.get(ctx) }
    val lib = remember { Library.get(ctx) }
    var screen by remember { mutableStateOf("home") }
    var selected by remember { mutableStateOf<String?>(null) }
    var bios by remember { mutableStateOf(BiosManager.current(ctx)) }
    var msg by remember { mutableStateOf<String?>(null) }
    var askBios by remember { mutableStateOf<Game?>(null) }
    val coreOk = remember { CoreInfo.available(ctx) }

    fun rescan() {
        val u = settings.libraryUri
        if (u.isNotEmpty()) scope.launch { lib.scan(android.net.Uri.parse(u), settings.downloadCovers) }
    }

    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            settings.libraryUri = uri.toString()
            rescan()
        }
    }
    val biosPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val r = BiosManager.import(ctx, uri)
            bios = BiosManager.current(ctx)
            msg = r.fold({ "BIOS importada: $it" }, { it.message ?: "Erro ao importar a BIOS." })
        }
    }

    // Reescaneia automaticamente ao abrir o app (pasta já autorizada).
    LaunchedEffect(Unit) { rescan() }

    fun launchGame(g: Game) {
        ctx.startActivity(Intent(ctx, EmulatorActivity::class.java).putExtra("id", g.id))
    }

    BackHandler(screen == "settings") { screen = "home" }

    if (screen == "settings") {
        SettingsScreen(
            settings, lib, bios, coreOk,
            onBack = { screen = "home" },
            onPickFolder = { folderPicker.launch(null) },
            onRescan = { rescan() },
            onImportBios = { biosPicker.launch(arrayOf("*/*")) }
        )
    } else {
        HomeScreen(
            lib, bios, coreOk, selected,
            onSelect = { selected = it },
            onImportGames = { folderPicker.launch(null) },
            onImportBios = { biosPicker.launch(arrayOf("*/*")) },
            onPlay = { g -> if (bios.ok) launchGame(g) else askBios = g },
            onSettings = { screen = "settings" }
        )
    }

    msg?.let {
        AlertDialog(onDismissRequest = { msg = null }, confirmButton = { TextButton(onClick = { msg = null }) { Text("OK") } }, text = { Text(it) })
    }
    askBios?.let { g ->
        AlertDialog(
            onDismissRequest = { askBios = null },
            title = { Text("BIOS não encontrada") },
            text = { Text("Importe a BIOS do seu PS1 para melhor compatibilidade. Você também pode jogar sem BIOS usando a BIOS simulada (HLE) do núcleo, com menos compatibilidade.") },
            confirmButton = { TextButton(onClick = { askBios = null; biosPicker.launch(arrayOf("*/*")) }) { Text("IMPORTAR BIOS") } },
            dismissButton = { TextButton(onClick = { askBios = null; launchGame(g) }) { Text("JOGAR MESMO ASSIM") } }
        )
    }
}

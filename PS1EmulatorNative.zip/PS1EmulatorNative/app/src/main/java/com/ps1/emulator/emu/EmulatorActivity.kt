package com.ps1.emulator.emu

import android.annotation.SuppressLint
import android.os.Build
import android.os.Bundle
import android.os.PerformanceHintManager
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import android.opengl.GLSurfaceView
import com.ps1.emulator.core.CoreInfo
import com.ps1.emulator.core.NativeBridge
import com.ps1.emulator.data.BiosManager
import com.ps1.emulator.data.Game
import com.ps1.emulator.data.GameStager
import com.ps1.emulator.data.Library
import com.ps1.emulator.data.Settings
import com.ps1.emulator.ui.PS1Theme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.abs
import kotlin.math.max

class UiState {
    var phase by mutableStateOf("loading")   // loading | running | error
    var progress by mutableFloatStateOf(0f)
    var error by mutableStateOf("")
    var menu by mutableStateOf(false)
    var edit by mutableStateOf(false)
    var stats by mutableStateOf("")
    var fast by mutableStateOf(false)
    var selScale by mutableFloatStateOf(1f)
    var hasSel by mutableStateOf(false)
    var padShown by mutableStateOf(true)
}

class EmulatorActivity : ComponentActivity() {
    private val ui = UiState()
    private lateinit var settings: Settings
    private lateinit var gl: GLSurfaceView
    private lateinit var pad: VirtualPad
    private var game: Game? = null
    private var started = false
    private var gpuName = ""

    private var padMask = 0; private var padLx = 0; private var padLy = 0; private var padRx = 0; private var padRy = 0
    private var physMask = 0; private var hatMask = 0; private var trigMask = 0
    private var physLx = 0; private var physLy = 0; private var physRx = 0; private var physRy = 0

    private var hint: Any? = null

    @SuppressLint("NewApi")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = Settings.get(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        WindowCompat.setDecorFitsSystemWindows(window, false)
        hideBars()

        val root = FrameLayout(this)
        gl = GLSurfaceView(this).apply {
            setEGLContextClientVersion(3)
            setEGLConfigChooser(8, 8, 8, 0, 0, 0)
            setRenderer(object : GLSurfaceView.Renderer {
                override fun onSurfaceCreated(g: GL10?, c: EGLConfig?) { gpuName = NativeBridge.nativeSurfaceCreated() }
                override fun onSurfaceChanged(g: GL10?, w: Int, h: Int) = NativeBridge.nativeSurfaceChanged(w, h)
                override fun onDrawFrame(g: GL10?) = NativeBridge.nativeDrawFrame()
            })
            renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
            holder.addCallback(object : SurfaceHolder.Callback {
                override fun surfaceCreated(h: SurfaceHolder) {
                    if (Build.VERSION.SDK_INT >= 30) h.surface.setFrameRate(60f, android.view.Surface.FRAME_RATE_COMPATIBILITY_DEFAULT)
                }
                override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, hh: Int) {}
                override fun surfaceDestroyed(h: SurfaceHolder) {}
            })
        }
        root.addOnLayoutChangeListener { _, l, t, r, b, _, _, _, _ ->
            val w = r - l; val h = b - t
            if (w > 0 && h > 0) {
                val s = settings.resScale / 100f
                if (s < 0.99f) gl.holder.setFixedSize((w * s).toInt(), (h * s).toInt()) else gl.holder.setSizeFromLayout()
            }
        }
        pad = VirtualPad(this, settings).also { p ->
            p.listener = { m, lx, ly, rx, ry -> padMask = m; padLx = lx; padLy = ly; padRx = rx; padRy = ry; pushInput() }
            p.onSelect = { s -> ui.hasSel = s != null; if (s != null) ui.selScale = s }
        }
        ui.padShown = settings.showPad
        pad.visibility = if (ui.padShown) android.view.View.VISIBLE else android.view.View.GONE

        val lp = { FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT) }
        root.addView(gl, lp())
        root.addView(pad, lp())
        root.addView(ComposeView(this).apply { setContent { PS1Theme { Overlay() } } }, lp())
        setContentView(root)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { if (ui.phase == "running") setMenu(!ui.menu) else finish() }
        })

        val id = intent.getStringExtra("id")
        game = Library.get(this).games.firstOrNull { it.id == id }
        val g = game
        if (g == null) { ui.phase = "error"; ui.error = "Jogo não encontrado na biblioteca. Volte e reescaneie a pasta." } else load(g)
    }

    private fun hideBars() {
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    // ---------- inicialização do jogo ----------
    private fun load(g: Game) = lifecycleScope.launch {
        try {
            val main = withContext(Dispatchers.IO) {
                GameStager.stage(applicationContext, g, settings.cacheGames) { ui.progress = it }
            }
            val err = withContext(Dispatchers.IO) { startCore(g, main) }
            if (err != null) { ui.error = err; ui.phase = "error"; return@launch }
            started = true
            ui.phase = "running"
            Library.get(this@EmulatorActivity).markPlayed(g.id)
            setupHint()
            statsLoop()
        } catch (e: Exception) {
            ui.error = e.message ?: e.toString(); ui.phase = "error"
        }
    }

    private fun applyConfig() = NativeBridge.nativeSetConfig(
        settings.fpsLimit, settings.audioOn, settings.audioSync, settings.volume,
        settings.bilinear, settings.aspect, settings.vsync, settings.analogPad
    )

    private fun startCore(g: Game, main: File): String? {
        val nb = NativeBridge
        if (!CoreInfo.available(this)) {
            return "Núcleo PCSX-ReARMed não encontrado no APK.\n\nColoque libpcsx_rearmed_libretro.so em app/src/main/jniLibs/arm64-v8a/ (rode scripts/fetch_core.sh) e recompile."
        }
        settings.coreOptions().forEach { (k, v) -> nb.nativeSetOption(k, v) }
        applyConfig()
        val saves = File(filesDir, "saves").apply { mkdirs() }
        File(filesDir, "states").mkdirs()
        val rc = nb.nativeInit(applicationInfo.nativeLibraryDir, BiosManager.dir(this).path, saves.path)
        if (rc != 0) return "Falha ao iniciar o núcleo (código $rc):\n${nb.nativeLastError()}"
        if (!nb.nativeLoadGame(main.path, File(saves, "${g.id}.mcr").path)) {
            val e = nb.nativeLastError()
            nb.nativeStop()
            return "O núcleo não conseguiu abrir o jogo.\n$e"
        }
        nb.nativeStart()
        return null
    }

    @SuppressLint("NewApi")
    private fun setupHint() {
        if (Build.VERSION.SDK_INT < 31) return
        try {
            val m = getSystemService(PerformanceHintManager::class.java)
            val tid = NativeBridge.nativeEmuTid()
            if (m != null && tid > 0) hint = m.createHintSession(intArrayOf(tid), 16_666_667L)
        } catch (_: Throwable) { }
    }

    @SuppressLint("NewApi")
    private fun statsLoop() = lifecycleScope.launch {
        while (isActive) {
            delay(500)
            val s = NativeBridge.nativeGetStats()
            ui.stats = String.format(Locale.US, "%.0f FPS • %.1f ms • áudio: %d falhas • %s", s[0], s[1], s[2].toInt(), gpuName)
            if (Build.VERSION.SDK_INT >= 31) {
                try { (hint as? PerformanceHintManager.Session)?.reportActualWorkDuration((s[1] * 1_000_000f).toLong().coerceAtLeast(1L)) } catch (_: Throwable) { }
            }
        }
    }

    // ---------- menu / pausa ----------
    private fun setMenu(open: Boolean) {
        ui.menu = open
        NativeBridge.nativePause(open || ui.edit)
    }

    private fun stateFile(slot: Int) = File(File(filesDir, "states"), "${game?.id}_$slot.state").path

    private fun stateAction(save: Boolean, slot: Int) = lifecycleScope.launch {
        val ok = withContext(Dispatchers.IO) {
            if (save) NativeBridge.nativeSaveState(stateFile(slot)) else NativeBridge.nativeLoadState(stateFile(slot))
        }
        Toast.makeText(this@EmulatorActivity,
            if (ok) (if (save) "Estado $slot salvo" else "Estado $slot carregado") else (if (save) "Falha ao salvar" else "Nenhum estado salvo no slot $slot"),
            Toast.LENGTH_SHORT).show()
        if (ok) setMenu(false)
    }

    // ---------- entrada (controle físico) ----------
    private fun pushInput() {
        val mask = padMask or physMask or hatMask or trigMask
        NativeBridge.nativeSetInput(
            mask,
            if (padLx != 0) padLx else physLx, if (padLy != 0) padLy else physLy,
            if (padRx != 0) padRx else physRx, if (padRy != 0) padRy else physRy
        )
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val fromPad = (e.source and (InputDevice.SOURCE_GAMEPAD or InputDevice.SOURCE_JOYSTICK or InputDevice.SOURCE_DPAD)) != 0
        if (fromPad) {
            if (e.keyCode == KeyEvent.KEYCODE_BUTTON_MODE) {
                if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0 && ui.phase == "running") setMenu(!ui.menu)
                return true
            }
            val bit = when (e.keyCode) {
                KeyEvent.KEYCODE_BUTTON_A -> 0      // ✕
                KeyEvent.KEYCODE_BUTTON_B -> 8      // ○
                KeyEvent.KEYCODE_BUTTON_X -> 1      // □
                KeyEvent.KEYCODE_BUTTON_Y -> 9      // △
                KeyEvent.KEYCODE_BUTTON_L1 -> 10
                KeyEvent.KEYCODE_BUTTON_R1 -> 11
                KeyEvent.KEYCODE_BUTTON_L2 -> 12
                KeyEvent.KEYCODE_BUTTON_R2 -> 13
                KeyEvent.KEYCODE_BUTTON_THUMBL -> 14
                KeyEvent.KEYCODE_BUTTON_THUMBR -> 15
                KeyEvent.KEYCODE_BUTTON_SELECT -> 2
                KeyEvent.KEYCODE_BUTTON_START -> 3
                KeyEvent.KEYCODE_DPAD_UP -> 4
                KeyEvent.KEYCODE_DPAD_DOWN -> 5
                KeyEvent.KEYCODE_DPAD_LEFT -> 6
                KeyEvent.KEYCODE_DPAD_RIGHT -> 7
                else -> -1
            }
            if (bit >= 0) {
                if (e.action == KeyEvent.ACTION_DOWN) physMask = physMask or (1 shl bit)
                else if (e.action == KeyEvent.ACTION_UP) physMask = physMask and (1 shl bit).inv()
                pushInput()
                return true
            }
        }
        return super.dispatchKeyEvent(e)
    }

    private fun axis(e: MotionEvent, a: Int): Float {
        val v = e.getAxisValue(a)
        return if (abs(v) < 0.15f) 0f else v
    }

    override fun onGenericMotionEvent(e: MotionEvent): Boolean {
        if ((e.source and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK && e.action == MotionEvent.ACTION_MOVE) {
            val lx = axis(e, MotionEvent.AXIS_X); val ly = axis(e, MotionEvent.AXIS_Y)
            physLx = (lx * 32767).toInt(); physLy = (ly * 32767).toInt()
            physRx = (axis(e, MotionEvent.AXIS_Z) * 32767).toInt(); physRy = (axis(e, MotionEvent.AXIS_RZ) * 32767).toInt()
            var hat = 0
            val hx = e.getAxisValue(MotionEvent.AXIS_HAT_X); val hy = e.getAxisValue(MotionEvent.AXIS_HAT_Y)
            if (hy < -0.5f) hat = hat or (1 shl 4)
            if (hy > 0.5f) hat = hat or (1 shl 5)
            if (hx < -0.5f) hat = hat or (1 shl 6)
            if (hx > 0.5f) hat = hat or (1 shl 7)
            if (!settings.analogPad) {  // modo digital: analógico esquerdo vira direcional
                if (ly < -0.5f) hat = hat or (1 shl 4)
                if (ly > 0.5f) hat = hat or (1 shl 5)
                if (lx < -0.5f) hat = hat or (1 shl 6)
                if (lx > 0.5f) hat = hat or (1 shl 7)
            }
            hatMask = hat
            var t = 0
            if (max(e.getAxisValue(MotionEvent.AXIS_LTRIGGER), e.getAxisValue(MotionEvent.AXIS_BRAKE)) > 0.5f) t = t or (1 shl 12)
            if (max(e.getAxisValue(MotionEvent.AXIS_RTRIGGER), e.getAxisValue(MotionEvent.AXIS_GAS)) > 0.5f) t = t or (1 shl 13)
            trigMask = t
            pushInput()
            return true
        }
        return super.onGenericMotionEvent(e)
    }

    // ---------- ciclo de vida ----------
    override fun onPause() {
        super.onPause()
        if (started) {
            NativeBridge.nativePause(true)
            Thread { NativeBridge.nativeFlushRam() }.start()   // grava o memory card
        }
    }

    override fun onResume() {
        super.onResume()
        hideBars()
        if (started && !ui.menu && !ui.edit) NativeBridge.nativePause(false)
    }

    override fun onDestroy() {
        super.onDestroy()
        if (Build.VERSION.SDK_INT >= 31) try { (hint as? PerformanceHintManager.Session)?.close() } catch (_: Throwable) { }
        if (started) { started = false; NativeBridge.nativeStop() }
    }

    // ---------- interface sobreposta ----------
    @Composable
    private fun Overlay() {
        Box(Modifier.fillMaxSize()) {
            if (ui.phase == "running") {
                if (settings.showFps && ui.stats.isNotEmpty()) {
                    Text(
                        ui.stats, Modifier.align(Alignment.TopStart).padding(8.dp)
                            .background(Color(0x99000000), RoundedCornerShape(6.dp)).padding(horizontal = 8.dp, vertical = 3.dp),
                        color = Color.White, fontSize = 11.sp, fontFamily = FontFamily.Monospace
                    )
                }
                if (!ui.edit) {
                    TextButton(
                        onClick = { setMenu(true) },
                        modifier = Modifier.align(Alignment.TopEnd).padding(4.dp)
                    ) { Text("☰", color = Color.White.copy(alpha = 0.7f), fontSize = 22.sp) }
                }
            }
            if (ui.phase == "loading") {
                Surface(Modifier.fillMaxSize(), color = Color(0xFF0D1117)) {
                    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(game?.title ?: "", color = Color.White, fontSize = 18.sp)
                        Spacer(Modifier.height(12.dp))
                        Text("Preparando jogo… ${(ui.progress * 100).toInt()}%", color = Color(0xFF9DA7B3))
                        Spacer(Modifier.height(12.dp))
                        LinearProgressIndicator(progress = { ui.progress }, modifier = Modifier.width(260.dp))
                    }
                }
            }
            if (ui.phase == "error") {
                AlertDialog(
                    onDismissRequest = { finish() },
                    title = { Text("Não foi possível iniciar") },
                    text = { Text(ui.error) },
                    confirmButton = { TextButton(onClick = { finish() }) { Text("VOLTAR") } }
                )
            }
            if (ui.edit) {
                Surface(
                    Modifier.align(Alignment.BottomCenter).padding(bottom = 4.dp).widthIn(max = 520.dp).fillMaxWidth(0.7f),
                    shape = RoundedCornerShape(14.dp), color = Color(0xE6161B22)
                ) {
                    Column(Modifier.padding(horizontal = 14.dp, vertical = 8.dp)) {
                        Text(
                            if (ui.hasSel) "Arraste para mover • tamanho: ${(ui.selScale * 100).toInt()}%" else "Toque em um botão para selecionar e arraste para mover",
                            color = Color.White, fontSize = 12.sp
                        )
                        if (ui.hasSel) Slider(ui.selScale, { ui.selScale = it; pad.setSelectedScale(it) }, valueRange = 0.5f..2f)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { pad.resetLayout() }) { Text("Restaurar") }
                            Button(onClick = {
                                pad.saveLayout(); pad.edit = false; ui.edit = false; ui.hasSel = false
                                NativeBridge.nativePause(ui.menu)
                            }) { Text("Concluir") }
                        }
                    }
                }
            }
            if (ui.menu) {
                Dialog(onDismissRequest = { setMenu(false) }) {
                    Surface(shape = RoundedCornerShape(16.dp), color = Color(0xFF161B22)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(game?.title ?: "Menu", fontSize = 16.sp, color = Color.White)
                            Button(onClick = { setMenu(false) }, Modifier.fillMaxWidth()) { Text("Continuar") }
                            OutlinedButton(onClick = { lifecycleScope.launch(Dispatchers.IO) { NativeBridge.nativeReset() }; setMenu(false) }, Modifier.fillMaxWidth()) { Text("Reiniciar") }
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                for (s in 1..3) OutlinedButton(onClick = { stateAction(true, s) }, contentPadding = PaddingValues(4.dp), modifier = Modifier.weight(1f)) { Text("Salvar $s", fontSize = 12.sp) }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                for (s in 1..3) OutlinedButton(onClick = { stateAction(false, s) }, contentPadding = PaddingValues(4.dp), modifier = Modifier.weight(1f)) { Text("Carregar $s", fontSize = 12.sp) }
                            }
                            OutlinedButton(onClick = {
                                ui.fast = !ui.fast; NativeBridge.nativeSetSpeed(if (ui.fast) 2f else 1f)
                            }, Modifier.fillMaxWidth()) { Text(if (ui.fast) "Velocidade 2x: ligada" else "Velocidade 2x: desligada") }
                            OutlinedButton(onClick = {
                                ui.padShown = !ui.padShown; settings.showPad = ui.padShown
                                pad.visibility = if (ui.padShown) android.view.View.VISIBLE else android.view.View.GONE
                            }, Modifier.fillMaxWidth()) { Text(if (ui.padShown) "Ocultar controles na tela" else "Mostrar controles na tela") }
                            OutlinedButton(onClick = {
                                ui.padShown = true; settings.showPad = true; pad.visibility = android.view.View.VISIBLE
                                ui.menu = false; ui.edit = true; pad.edit = true
                                NativeBridge.nativePause(true)
                            }, Modifier.fillMaxWidth()) { Text("Editar controles") }
                            TextButton(onClick = { finish() }, Modifier.fillMaxWidth()) { Text("Sair do jogo", color = Color(0xFFFF7B72)) }
                        }
                    }
                }
            }
        }
    }
}

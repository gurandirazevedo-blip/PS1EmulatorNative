# PS1 Emulator Native

Emulador de PlayStation 1 para Android (ARM64). Interface em português, biblioteca de jogos, importação de pasta e de BIOS, controles virtuais, controle Bluetooth e configurações.
O motor é o núcleo **PCSX-ReARMed** (código aberto, GPLv2). **O app não inclui BIOS nem jogos**: use os da sua própria console.

---

## GUIA SIMPLES PARA QUEM USA ANDROID + CodeAssist

O CodeAssist **não consegue compilar código C++** (este app precisa). Por isso o APK é montado de graça pelo GitHub, sozinho, e você só baixa.

### Passo 1 — Colocar o projeto no GitHub (pelo celular)
1. Crie uma conta em github.com e um repositório novo (botão **+** > *New repository*), nome: `PS1EmulatorNative`.
2. Descompacte o ZIP no celular (gerenciador de arquivos).
3. No Termux (recomendado, pois pastas ocultas como `.github` não sobem pelo navegador):
   ```
   pkg install git
   cd /sdcard/Download/PS1EmulatorNative
   git init && git add -A && git commit -m "PS1 Emulator Native"
   git branch -M main
   git remote add origin https://github.com/SEU_USUARIO/PS1EmulatorNative.git
   git push -u origin main
   ```
   (o GitHub pede seu usuário e um *token* em Settings > Developer settings > Personal access tokens, permissão *repo*).
4. Sem Termux? No navegador do GitHub: *Add file > Upload files* e envie tudo. Depois *Add file > Create new file*, digite o nome `.github/workflows/build.yml` e cole o conteúdo do arquivo `workflow/build.yml` do projeto.

### Passo 2 — Gerar o APK
1. No repositório abra a aba **Actions**. O build começa sozinho (ou toque em *Build APK PS1 Emulator Native* > *Run workflow*).
2. Espere uns 15–40 minutos até aparecer o ✔ verde.
3. Toque na execução, role até **Artifacts** e baixe **PS1EmulatorNative-apk**. Descompacte e instale `PS1EmulatorNative.apk` (permita instalar apps desconhecidos).
4. Se aparecer ✖ vermelho, abra o passo que falhou e me envie o texto do erro.

### Passo 3 — Usar
1. Abra o app. 2. **IMPORTAR JOGOS** e escolha a pasta (BIN/CUE, ISO, CHD ou PBP). 3. **IMPORTAR BIOS** e escolha seu arquivo de 512 KB. 4. Toque no jogo e em **JOGAR**.
Capas: ponha `NomeDoJogo.jpg/.png` na pasta dos jogos, ou deixe "Baixar capas online" ligado (Configurações > Biblioteca).

---

## Como o núcleo é obtido (automático)
`scripts/build_core.sh` (chamado pelo workflow):
1. Clona o código-fonte oficial `github.com/libretro/pcsx_rearmed` (com submódulos) e compila com o NDK 27 (`jni/Android.mk`) para **arm64-v8a**.
2. Se a compilação falhar, baixa o binário oficial do buildbot do libretro.
3. Valida que a `.so` exporta a API libretro. Se nada funcionar, o build **falha** (nunca gera APK sem núcleo). O Gradle também falha com `verifyCore` se a `.so` não existir.
O commit usado fica registrado em `CORE_VERSION.txt` dentro do artefato.

## Compilar no PC (Android Studio)
`bash scripts/build_core.sh` (precisa de NDK 27.0.12077973 e internet), depois abra o projeto e *Build > Build APK*.

## Estrutura
- `app/src/main/cpp/emu.cpp` + `CMakeLists.txt`: frontend libretro (dlopen do núcleo, thread de emulação, OpenGL ES 3, AAudio, entrada, memory card, save states).
- `core/`, `data/`, `ui/`, `emu/`: ponte JNI, biblioteca/BIOS, telas Compose, jogo e controles.
- `tests/native/`: teste automático do frontend nativo (roda no workflow).
- `workflow/build.yml`: cópia do workflow para colar no GitHub se a pasta `.github` não subir.

## O que foi testado e o que não foi
Testado (PC x86, com um núcleo libretro falso): carregamento do núcleo por dlopen e dos 21 símbolos, rejeição de jogo inválido, `retro_load_game` com arquivo CUE, loop a ~60 FPS, entrega de entrada e de opções ao núcleo, save/load state, memory card, reset, pausa, parada limpa, chamadas do renderizador. Verificação de sintaxe do C++ e do script de build.
**Não testado** (precisa do GitHub Actions/aparelho): compilação do núcleo real, compilação Kotlin/Gradle, APK, áudio AAudio, vídeo OpenGL na GPU real, jogos reais, desempenho em Mali/Adreno/MediaTek.

## Licença
PCSX-ReARMed é GPLv2: ao distribuir o APK, distribua também o código-fonte deste projeto.

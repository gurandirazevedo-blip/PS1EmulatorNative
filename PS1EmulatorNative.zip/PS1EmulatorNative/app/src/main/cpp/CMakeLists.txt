cmake_minimum_required(VERSION 3.22.1)
project(ps1native LANGUAGES CXX)

add_library(ps1native SHARED emu.cpp)
target_compile_options(ps1native PRIVATE -O2 -fvisibility=hidden -Wall)
target_link_options(ps1native PRIVATE -Wl,-z,max-page-size=16384)
find_library(log-lib log)
target_link_libraries(ps1native ${log-lib} android EGL GLESv3 aaudio dl)

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <string.h>
#include <stdio.h>
typedef bool (*env_t)(unsigned, void*);
typedef void (*vid_t)(const void*, unsigned, unsigned, size_t);
typedef size_t (*aud_t)(const int16_t*, size_t);
typedef int16_t (*inp_t)(unsigned, unsigned, unsigned, unsigned);
static env_t env; static vid_t vid; static aud_t aud; static inp_t inp;
static int frames, last_mask, opt_seen, loaded, resets; static uint16_t fb[64*48]; static uint8_t ram[131072];
struct sysinfo { const char* a; const char* b; const char* c; bool d; bool e; };
struct game { const char* path; const void* data; size_t size; const char* meta; };
struct geom { unsigned bw, bh, mw, mh; float ar; };
struct av { struct geom g; double fps, rate; };
struct var { const char* key; const char* value; };
void retro_set_environment(env_t e){ env=e; } void retro_set_video_refresh(vid_t v){ vid=v; }
void retro_set_audio_sample(void* a){ (void)a; } void retro_set_audio_sample_batch(aud_t a){ aud=a; }
void retro_set_input_poll(void* p){ (void)p; } void retro_set_input_state(inp_t i){ inp=i; }
void retro_init(void){ int fmt=2; env(10,&fmt); struct var v={"pcsx_rearmed_drc",0}; if(env(15,&v)&&v.value&&!strcmp(v.value,"enabled")) opt_seen=1; }
void retro_deinit(void){} unsigned retro_api_version(void){ return 1; }
void retro_get_system_info(struct sysinfo* s){ memset(s,0,sizeof *s); s->a="fake"; s->b="1"; s->c="cue|bin"; s->d=true; }
void retro_get_system_av_info(struct av* a){ a->g.bw=64;a->g.bh=48;a->g.mw=64;a->g.mh=48;a->g.ar=4.f/3.f;a->fps=60;a->rate=44100; }
void retro_set_controller_port_device(unsigned p, unsigned d){ (void)p;(void)d; }
void retro_reset(void){ resets++; frames=0; }
bool retro_load_game(const struct game* g){ loaded = g && g->path && strstr(g->path,"test.cue"); return loaded; }
void retro_unload_game(void){ loaded=0; }
void retro_run(void){
  last_mask = inp(0,1,0,256); frames++;
  for(int i=0;i<64*48;i++) fb[i]=(uint16_t)(frames*257);
  vid(fb,64,48,64*2);
  int16_t a[735*2]; memset(a,0,sizeof a); aud(a,735);
  ram[0]=(uint8_t)frames;
}
size_t retro_serialize_size(void){ return 4; }
bool retro_serialize(void* d,size_t n){ if(n<4) return false; memcpy(d,&frames,4); return true; }
bool retro_unserialize(const void* d,size_t n){ if(n<4) return false; memcpy(&frames,d,4); return true; }
void* retro_get_memory_data(unsigned id){ return id==0?ram:0; } size_t retro_get_memory_size(unsigned id){ return id==0?sizeof ram:0; }
void fake_stats(int* o){ o[0]=frames; o[1]=last_mask; o[2]=opt_seen; o[3]=resets; }

#!/usr/bin/env bash
# Teste funcional do frontend nativo (emu.cpp) no PC, com um núcleo libretro falso.
set -e
cd "$(dirname "$0")"
T=/tmp/t; rm -rf "$T"; mkdir -p "$T/lib"
gcc -shared -fPIC -O1 -o "$T/lib/libpcsx_rearmed_libretro.so" fake_core.c
g++ -std=c++17 -O1 -Istub -I../../app/src/main/cpp ../../app/src/main/cpp/emu.cpp harness.cpp stubs.cpp -ldl -lpthread -o "$T/harness"
touch "$T/test.cue"
"$T/harness" "$T/lib"

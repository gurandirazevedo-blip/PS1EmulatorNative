#pragma once
typedef void* EGLDisplay; EGLDisplay eglGetCurrentDisplay(); unsigned eglSwapInterval(EGLDisplay,int);

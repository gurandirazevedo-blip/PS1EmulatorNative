@file:OptIn(ExperimentalMaterial3Api::class)

package com.ps1.emulator.ui

import android.os.Build
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.ps1.emulator.data.BiosManager
import com.ps1.emulator.data.GameStager
import com.ps1.emulator.data.Library
import com.ps1.emulator.data.Settings
import androidx.compose.ui.platform.LocalContext
import kotlin.math.roundToInt

@Composable
private fun Section(content: @Composable ColumnScope.() -> Unit) =
    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp), content = content)

@Composable
private fun SwitchRow(title: String, sub: String?, v: Boolean, on: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { on(!v) }, verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title)
            if (sub != null) Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(v, on)
    }
}

@Composable
private fun <T> ChoiceRow(title: String, options: List<Pair<String, T>>, current: T, on: (T) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(title)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEach { (l, v) -> FilterChip(selected = current == v, onClick = { on(v) }, label = { Text(l) }) }
        }
    }
}

@Composable
private fun SliderRow(title: String, v: Float, range: ClosedFloatingPointRange<Float>, label: String, on: (Float) -> Unit) {
    Column { Text("$title: $label"); Slider(v, on, valueRange = range) }
}

@Composable
private fun Hint(t: String) = Text(t, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

@Composable
fun SettingsScreen(
    settings: Settings, lib: Library, bios: BiosManager.Info, coreOk: Boolean,
    onBack: () -> Unit, onPickFolder: () -> Unit, onRescan: () -> Unit, onImportBios: () -> Unit
) {
    val ctx = LocalContext.current
    val tabs = listOf("Vídeo", "Áudio", "Controles", "BIOS", "Biblioteca", "Desempenho", "Idioma")
    var tab by remember { mutableIntStateOf(0) }
    var cacheMb by remember { mutableLongStateOf(GameStager.cacheBytes(ctx) / 1048576) }

    Scaffold(
        containerColor = Bg,
        topBar = {
            TopAppBar(
                title = { Text("Configurações") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Bg, titleContentColor = Color.White, navigationIconContentColor = Color.White)
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            ScrollableTabRow(selectedTabIndex = tab, containerColor = Bg, edgePadding = 8.dp) {
                tabs.forEachIndexed { i, t -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) }) }
            }
            Column(Modifier.verticalScroll(rememberScrollState())) {
                when (tab) {
                    0 -> Section {
                        ChoiceRow("Escala de resolução", listOf("50%" to 50, "75%" to 75, "100%" to 100), settings.resScale) { settings.resScale = it }
                        Hint("Reduz a resolução da tela de jogo para ganhar desempenho em GPUs fracas (Mali/Adreno de entrada).")
                        ChoiceRow("Proporção da imagem", listOf("4:3 (original)" to 0, "Do núcleo" to 1, "Esticar" to 2), settings.aspect) { settings.aspect = it }
                        SwitchRow("Filtro bilinear", "Suaviza os pixels. Desligado = pixels nítidos.", settings.bilinear) { settings.bilinear = it }
                        SwitchRow("VSync", "Evita rasgos na imagem. Desligue apenas para testes.", settings.vsync) { settings.vsync = it }
                        SwitchRow("Mostrar FPS e tempo de quadro", null, settings.showFps) { settings.showFps = it }
                        SwitchRow("Resolução melhorada (núcleo)", "Renderização interna maior no PCSX-ReARMed (NEON). Exige CPU forte.", settings.enhance) { settings.enhance = it }
                    }
                    1 -> Section {
                        SwitchRow("Áudio ativado", null, settings.audioOn) { settings.audioOn = it }
                        SwitchRow("Sincronizar com o áudio", "Mantém a velocidade estável e sem estalos.", settings.audioSync) { settings.audioSync = it }
                        SliderRow("Volume", settings.volume.toFloat(), 0f..100f, "${settings.volume}%") { settings.volume = it.roundToInt() }
                    }
                    2 -> Section {
                        SwitchRow("Mostrar controle virtual", null, settings.showPad) { settings.showPad = it }
                        ChoiceRow("Tipo de controle", listOf("Analógico (DualShock)" to true, "Digital" to false), settings.analogPad) { settings.analogPad = it }
                        SliderRow("Opacidade", settings.padOpacity, 0.15f..1f, "${(settings.padOpacity * 100).roundToInt()}%") { settings.padOpacity = it }
                        SliderRow("Tamanho geral", settings.padScale, 0.6f..1.6f, "${(settings.padScale * 100).roundToInt()}%") { settings.padScale = it }
                        SwitchRow("Vibração ao tocar", null, settings.haptics) { settings.haptics = it }
                        OutlinedButton(onClick = { settings.padLayout = "" }) { Text("Restaurar posições padrão") }
                        Hint("Para mover e redimensionar cada botão: durante o jogo, abra o menu (botão ☰ ou Voltar) e toque em “Editar controles”. Controles Bluetooth/USB funcionam automaticamente.")
                    }
                    3 -> Section {
                        Text(if (bios.ok) "BIOS atual: ${bios.label}" else "Nenhuma BIOS importada.")
                        Button(onClick = onImportBios) { Text("IMPORTAR BIOS") }
                        Hint("Use o dump da sua própria console (arquivo de 512 KB, ex.: scph1001.bin, scph5501.bin). O app não inclui nenhuma BIOS. Sem BIOS, o núcleo usa uma BIOS simulada (HLE) com menor compatibilidade.")
                    }
                    4 -> Section {
                        Text(if (settings.libraryUri.isEmpty()) "Nenhuma pasta selecionada." else "Pasta: " + android.net.Uri.parse(settings.libraryUri).lastPathSegment)
                        Text("${lib.games.size} jogo(s) • ${lib.status}")
                        Button(onClick = onPickFolder) { Text("SELECIONAR PASTA DE JOGOS") }
                        OutlinedButton(onClick = onRescan, enabled = settings.libraryUri.isNotEmpty() && !lib.scanning) { Text("Reescanear biblioteca") }
                        SwitchRow("Baixar capas online", "Busca capas em thumbnails.libretro.com pelo nome do arquivo. Capas locais (mesmo nome do jogo, .jpg/.png) têm prioridade.", settings.downloadCovers) { settings.downloadCovers = it }
                        ChoiceRow("Jogos mantidos preparados (cache)", listOf("1" to 1, "2" to 2, "3" to 3), settings.cacheGames) { settings.cacheGames = it }
                        Text("Cache atual: $cacheMb MB")
                        OutlinedButton(onClick = { GameStager.clear(ctx); cacheMb = 0 }) { Text("Limpar cache de jogos") }
                        OutlinedButton(onClick = { lib.clear() }) { Text("Limpar biblioteca") }
                    }
                    5 -> Section {
                        ChoiceRow("Perfil", listOf("Desempenho" to 0, "Equilibrado" to 1, "Compatibilidade" to 2), settings.profile) { settings.applyProfile(it) }
                        Hint("Desempenho: 75% da resolução e frameskip automático. Equilibrado: padrão. Compatibilidade: sem frameskip e resolução total.")
                        SwitchRow("Limitar FPS à velocidade original", "Jogos de PS1 rodam a 50/60 Hz (muitos a 30 FPS por design). Desligar deixa o jogo acelerado.", settings.fpsLimit) { settings.fpsLimit = it }
                        SwitchRow("Frameskip automático", "Pula quadros de vídeo quando o aparelho não acompanha.", settings.frameskip > 0) { settings.frameskip = if (it) 1 else 0 }
                        val soc = if (Build.VERSION.SDK_INT >= 31) "${Build.SOC_MANUFACTURER} ${Build.SOC_MODEL}" else "n/d"
                        Text("Aparelho: ${Build.MANUFACTURER} ${Build.MODEL}\nSoC: $soc\nABI: ${Build.SUPPORTED_ABIS.firstOrNull()}\nAndroid ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\nNúcleo: ${if (coreOk) "PCSX-ReARMed presente" else "AUSENTE"}")
                        Hint("A velocidade real depende do seu processador. O app não garante FPS: use o contador na tela para avaliar e ajuste o perfil.")
                    }
                    else -> Section {
                        Text("Português (Brasil)")
                        Hint("Este é o único idioma disponível nesta versão.")
                    }
                }
            }
        }
    }
}

#pragma once
#include <stdint.h>
typedef int jint; typedef unsigned char jboolean; typedef float jfloat; typedef void* jobject; typedef void* jstring; typedef void* jfloatArray;
#define JNI_TRUE 1
#define JNI_FALSE 0
#define JNIEXPORT
#define JNICALL
struct JNIEnv { const char* GetStringUTFChars(jstring,jboolean*); void ReleaseStringUTFChars(jstring,const char*); jstring NewStringUTF(const char*); jfloatArray NewFloatArray(int); void SetFloatArrayRegion(jfloatArray,int,int,const float*); };

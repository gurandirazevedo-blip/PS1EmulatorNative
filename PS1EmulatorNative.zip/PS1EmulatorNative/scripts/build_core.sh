#!/usr/bin/env bash
# Obtém o núcleo PCSX-ReARMed (libretro, GPLv2) para arm64-v8a e instala em jniLibs.
# 1) Compila a partir do código-fonte oficial (github.com/libretro/pcsx_rearmed) com o Android NDK.
# 2) Se falhar, baixa o binário oficial do buildbot do libretro.
# 3) Valida que a .so exporta a API libretro. Falha (exit 1) se não conseguir um núcleo válido.
set -uo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
DEST="$ROOT/app/src/main/jniLibs/arm64-v8a"
OUT="$DEST/libpcsx_rearmed_libretro.so"
WORK="$ROOT/.core-build"
NDK_VER="27.0.12077973"
mkdir -p "$DEST"

find_ndk() {
  for c in "${ANDROID_NDK_HOME:-}" "${ANDROID_NDK_ROOT:-}" "${ANDROID_NDK:-}" \
           "${ANDROID_HOME:-}/ndk/$NDK_VER" "${ANDROID_SDK_ROOT:-}/ndk/$NDK_VER"; do
    [ -n "$c" ] && [ -x "$c/ndk-build" ] && { echo "$c"; return 0; }
  done
  return 1
}

validate() {
  local f="$1" nm
  [ -s "$f" ] || return 1
  [ "$(head -c4 "$f" | tail -c3)" = "ELF" ] || { echo "Arquivo não é ELF"; return 1; }
  nm="$(command -v llvm-nm || true)"
  [ -z "$nm" ] && [ -n "${NDK:-}" ] && nm="$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-nm"
  [ -z "$nm" ] || [ ! -x "$nm" ] && nm="$(command -v nm)"
  local syms; syms="$("$nm" -D --defined-only "$f" 2>/dev/null || true)"
  for s in retro_init retro_run retro_load_game retro_set_environment retro_get_system_av_info; do
    echo "$syms" | grep -q " $s\$" || { echo "Símbolo libretro ausente: $s"; return 1; }
  done
  return 0
}

build_from_source() {
  NDK="$(find_ndk)" || { echo "NDK não encontrado"; return 1; }
  echo ">> Compilando PCSX-ReARMed do código-fonte oficial com NDK em $NDK"
  rm -rf "$WORK"; mkdir -p "$WORK"
  git clone --depth 1 --recurse-submodules --shallow-submodules \
      https://github.com/libretro/pcsx_rearmed.git "$WORK/src" || return 1
  ( cd "$WORK/src" && echo "pcsx_rearmed commit: $(git rev-parse HEAD)" | tee "$ROOT/CORE_VERSION.txt" )
  [ -d "$WORK/src/jni" ] || { echo "pasta jni/ não existe no repositório"; return 1; }
  ( cd "$WORK/src/jni" && "$NDK/ndk-build" -j"$(nproc)" \
      APP_ABI=arm64-v8a APP_PLATFORM=android-26 \
      NDK_PROJECT_PATH="$WORK/src" NDK_OUT="$WORK/obj" NDK_LIBS_OUT="$WORK/libs" ) || return 1
  local so; so="$(find "$WORK" -path '*arm64-v8a*' -name 'libretro.so' | head -n1)"
  [ -n "$so" ] || { echo "libretro.so não foi gerada"; return 1; }
  cp "$so" "$OUT"
}

download_prebuilt() {
  echo ">> Baixando binário oficial do buildbot libretro"
  local tmp; tmp="$(mktemp -d)"
  curl -L --fail --retry 3 \
    "https://buildbot.libretro.com/nightly/android/latest/arm64-v8a/pcsx_rearmed_libretro_android.so.zip" \
    -o "$tmp/core.zip" || return 1
  unzip -o "$tmp/core.zip" -d "$tmp" >/dev/null || return 1
  cp "$tmp/pcsx_rearmed_libretro_android.so" "$OUT" || return 1
  echo "pcsx_rearmed: binário do buildbot libretro (nightly)" > "$ROOT/CORE_VERSION.txt"
}

if [ -f "$OUT" ] && validate "$OUT"; then echo "Núcleo já presente e válido."; exit 0; fi
rm -f "$OUT"

if build_from_source && validate "$OUT"; then echo "OK: núcleo compilado do código-fonte."; exit 0; fi
echo "!! Compilação do código-fonte falhou; tentando binário oficial."
rm -f "$OUT"
if download_prebuilt && validate "$OUT"; then echo "OK: núcleo baixado."; exit 0; fi

rm -f "$OUT"
echo "ERRO: não foi possível obter um núcleo PCSX-ReARMed válido." >&2
exit 1

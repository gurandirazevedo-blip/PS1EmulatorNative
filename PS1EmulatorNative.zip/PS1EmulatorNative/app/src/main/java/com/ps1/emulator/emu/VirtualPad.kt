package com.ps1.emulator.emu

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import com.ps1.emulator.data.Settings
import org.json.JSONObject
import kotlin.math.hypot
import kotlin.math.min

/**
 * Controle virtual multitoque: direcional, dois analógicos, X/O/□/△, L1/L2/R1/R2, START/SELECT.
 * Posição e tamanho de cada controle são editáveis (modo edição) e salvos nas configurações.
 * Bits seguem os IDs do RetroPad: B=0 Y=1 SELECT=2 START=3 UP=4 DOWN=5 LEFT=6 RIGHT=7 A=8 X=9 L=10 R=11 L2=12 R2=13.
 */
class VirtualPad(ctx: Context, private val st: Settings) : View(ctx) {
    class Ctl(val id: String, var x: Float, var y: Float, var s: Float, val kind: Int, val label: String, val bit: Int, val color: Int)
    // kind: 0 = botão, 1 = direcional, 2 = analógico

    private val ctls = mutableListOf<Ctl>()
    var edit = false
        set(v) { field = v; if (!v) selected = null; invalidate() }
    var selected: Ctl? = null
        private set
    var listener: ((Int, Int, Int, Int, Int) -> Unit)? = null
    var onSelect: ((Float?) -> Unit)? = null

    private val owner = HashMap<Int, Ctl>()
    private val knob = HashMap<String, FloatArray>()
    private var lastMask = 0

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 4f }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; color = Color.WHITE }
    private val rect = RectF()

    init {
        ctls.addAll(defaults())
        loadLayout()
    }

    private fun defaults() = listOf(
        Ctl("dpad", .13f, .60f, 1f, 1, "", -1, 0),
        Ctl("lstick", .30f, .80f, 1f, 2, "L", -1, 0),
        Ctl("rstick", .70f, .80f, 1f, 2, "R", -1, 0),
        Ctl("cross", .86f, .80f, 1f, 0, "✕", 0, 0xFF5C9DFF.toInt()),
        Ctl("circle", .93f, .62f, 1f, 0, "○", 8, 0xFFFF6B6B.toInt()),
        Ctl("square", .79f, .62f, 1f, 0, "□", 1, 0xFFFF8CD9.toInt()),
        Ctl("triangle", .86f, .44f, 1f, 0, "△", 9, 0xFF5CE08A.toInt()),
        Ctl("l1", .07f, .10f, 1f, 0, "L1", 10, 0),
        Ctl("l2", .07f, .26f, 1f, 0, "L2", 12, 0),
        Ctl("r1", .93f, .10f, 1f, 0, "R1", 11, 0),
        Ctl("r2", .93f, .26f, 1f, 0, "R2", 13, 0),
        Ctl("select", .42f, .92f, 1f, 0, "SELECT", 2, 0),
        Ctl("start", .58f, .92f, 1f, 0, "START", 3, 0)
    )

    private fun loadLayout() {
        try {
            if (st.padLayout.isEmpty()) return
            val j = JSONObject(st.padLayout)
            ctls.forEach { c ->
                j.optJSONObject(c.id)?.let { o ->
                    c.x = o.optDouble("x", c.x.toDouble()).toFloat()
                    c.y = o.optDouble("y", c.y.toDouble()).toFloat()
                    c.s = o.optDouble("s", c.s.toDouble()).toFloat()
                }
            }
        } catch (_: Exception) { }
    }

    fun saveLayout() {
        val j = JSONObject()
        ctls.forEach { j.put(it.id, JSONObject().put("x", it.x.toDouble()).put("y", it.y.toDouble()).put("s", it.s.toDouble())) }
        st.padLayout = j.toString()
    }

    fun resetLayout() {
        ctls.clear(); ctls.addAll(defaults()); st.padLayout = ""; selected = null; onSelect?.invoke(null); invalidate()
    }

    fun setSelectedScale(v: Float) { selected?.s = v.coerceIn(0.5f, 2f); invalidate() }

    // ---------- geometria ----------
    private fun unit() = min(width, height).toFloat()
    private fun cx(c: Ctl) = c.x * width
    private fun cy(c: Ctl) = c.y * height
    private fun visible(c: Ctl) = !(c.kind == 2 && !st.analogPad)
    private fun radius(c: Ctl): Float {
        val f = when {
            c.kind == 1 -> 0.17f
            c.kind == 2 -> 0.14f
            c.label.length > 2 -> 0.055f
            c.id.startsWith("l") || c.id.startsWith("r") -> 0.065f
            else -> 0.075f
        }
        return unit() * f * c.s * st.padScale
    }
    private fun dist(x: Float, y: Float, c: Ctl) = hypot(x - cx(c), y - cy(c))

    private fun hit(x: Float, y: Float, slack: Float = 1.25f): Ctl? =
        ctls.filter { visible(it) && dist(x, y, it) < radius(it) * (if (it.kind == 0) slack else slack + 0.1f) }
            .minByOrNull { dist(x, y, it) }

    // ---------- toque ----------
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (edit) return editTouch(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                hit(e.getX(i), e.getY(i))?.let { owner[e.getPointerId(i)] = it }
            }
            MotionEvent.ACTION_MOVE -> for (i in 0 until e.pointerCount) {
                val pid = e.getPointerId(i)
                val c = owner[pid]
                val x = e.getX(i); val y = e.getY(i)
                if (c == null || (c.kind == 0 && dist(x, y, c) > radius(c) * 1.5f)) {
                    val n = hit(x, y)
                    if (n != null) owner[pid] = n else owner.remove(pid)
                }
            }
            MotionEvent.ACTION_POINTER_UP -> owner.remove(e.getPointerId(e.actionIndex))
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> owner.clear()
        }
        recompute(e)
        return true
    }

    private fun recompute(e: MotionEvent) {
        var m = 0; var lx = 0; var ly = 0; var rx = 0; var ry = 0
        knob.values.forEach { it[0] = 0f; it[1] = 0f }
        for ((pid, c) in owner) {
            val i = e.findPointerIndex(pid)
            if (i < 0) continue
            val r = radius(c)
            val dx = e.getX(i) - cx(c); val dy = e.getY(i) - cy(c)
            when (c.kind) {
                0 -> m = m or (1 shl c.bit)
                1 -> {
                    val nx = dx / r; val ny = dy / r
                    if (hypot(nx, ny) > 0.2f) {
                        if (nx > .38f) m = m or (1 shl 7)
                        if (nx < -.38f) m = m or (1 shl 6)
                        if (ny > .38f) m = m or (1 shl 5)
                        if (ny < -.38f) m = m or (1 shl 4)
                    }
                }
                2 -> {
                    var vx = dx / r; var vy = dy / r
                    val len = hypot(vx, vy)
                    if (len > 1f) { vx /= len; vy /= len }
                    knob.getOrPut(c.id) { FloatArray(2) }.also { it[0] = vx; it[1] = vy }
                    val ax = (vx * 32767).toInt(); val ay = (vy * 32767).toInt()
                    if (c.id == "lstick") { lx = ax; ly = ay } else { rx = ax; ry = ay }
                }
            }
        }
        if ((m and lastMask.inv()) != 0 && st.haptics) performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        lastMask = m
        listener?.invoke(m, lx, ly, rx, ry)
        invalidate()
    }

    private fun editTouch(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { selected = hit(e.x, e.y, 1.8f); onSelect?.invoke(selected?.s) }
            MotionEvent.ACTION_MOVE -> selected?.let { it.x = (e.x / width).coerceIn(0.03f, 0.97f); it.y = (e.y / height).coerceIn(0.04f, 0.96f) }
            MotionEvent.ACTION_UP -> saveLayout()
        }
        invalidate()
        return true
    }

    // ---------- desenho ----------
    private fun pressed(c: Ctl) = c.bit >= 0 && ((lastMask shr c.bit) and 1) == 1

    override fun onDraw(canvas: Canvas) {
        val a = if (edit) 255 else (st.padOpacity * 255).toInt()
        for (c in ctls) {
            if (!visible(c)) continue
            val x = cx(c); val y = cy(c); val r = radius(c)
            when (c.kind) {
                0 -> {
                    fill.color = Color.argb((a * (if (pressed(c)) 0.65f else 0.28f)).toInt(), 255, 255, 255)
                    line.color = Color.argb(a, 255, 255, 255)
                    if (c.label.length > 2) {
                        rect.set(x - r * 2f, y - r * 0.8f, x + r * 2f, y + r * 0.8f)
                        canvas.drawRoundRect(rect, r, r, fill); canvas.drawRoundRect(rect, r, r, line)
                        text.textSize = r * 0.9f; text.color = Color.argb(a, 255, 255, 255)
                        canvas.drawText(c.label, x, y + r * 0.3f, text)
                    } else {
                        canvas.drawCircle(x, y, r, fill); canvas.drawCircle(x, y, r, line)
                        text.textSize = if (c.label.length == 1) r * 1.1f else r * 0.8f
                        text.color = if (c.color != 0) (c.color and 0x00FFFFFF) or (a shl 24) else Color.argb(a, 255, 255, 255)
                        canvas.drawText(c.label, x, y + text.textSize * 0.35f, text)
                    }
                }
                1 -> {
                    val t = r * 0.36f
                    fill.color = Color.argb((a * 0.28f).toInt(), 255, 255, 255)
                    line.color = Color.argb(a, 255, 255, 255)
                    rect.set(x - r, y - t, x + r, y + t); canvas.drawRoundRect(rect, t, t, fill); canvas.drawRoundRect(rect, t, t, line)
                    rect.set(x - t, y - r, x + t, y + r); canvas.drawRoundRect(rect, t, t, fill); canvas.drawRoundRect(rect, t, t, line)
                    fill.color = Color.argb((a * 0.7f).toInt(), 255, 255, 255)
                    if ((lastMask shr 4) and 1 == 1) { rect.set(x - t, y - r, x + t, y - t); canvas.drawRoundRect(rect, t / 2, t / 2, fill) }
                    if ((lastMask shr 5) and 1 == 1) { rect.set(x - t, y + t, x + t, y + r); canvas.drawRoundRect(rect, t / 2, t / 2, fill) }
                    if ((lastMask shr 6) and 1 == 1) { rect.set(x - r, y - t, x - t, y + t); canvas.drawRoundRect(rect, t / 2, t / 2, fill) }
                    if ((lastMask shr 7) and 1 == 1) { rect.set(x + t, y - t, x + r, y + t); canvas.drawRoundRect(rect, t / 2, t / 2, fill) }
                }
                2 -> {
                    fill.color = Color.argb((a * 0.18f).toInt(), 255, 255, 255)
                    line.color = Color.argb(a, 255, 255, 255)
                    canvas.drawCircle(x, y, r, fill); canvas.drawCircle(x, y, r, line)
                    val k = knob[c.id]
                    val kx = x + (k?.get(0) ?: 0f) * r * 0.6f; val ky = y + (k?.get(1) ?: 0f) * r * 0.6f
                    fill.color = Color.argb((a * 0.55f).toInt(), 255, 255, 255)
                    canvas.drawCircle(kx, ky, r * 0.45f, fill)
                }
            }
            if (edit) {
                line.color = if (c === selected) Color.YELLOW else Color.argb(160, 120, 200, 255)
                val old = line.strokeWidth; line.strokeWidth = if (c === selected) 7f else 3f
                canvas.drawCircle(x, y, r * 1.25f, line); line.strokeWidth = old
            }
        }
    }
}

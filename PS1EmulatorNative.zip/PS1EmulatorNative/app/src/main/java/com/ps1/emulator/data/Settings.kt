package com.ps1.emulator.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

/** Preferência observável pelo Compose e salva automaticamente. */
class P<T>(private val sp: SharedPreferences, private val key: String, private val def: T) : ReadWriteProperty<Any?, T> {
    private val s = mutableStateOf(read())

    @Suppress("UNCHECKED_CAST")
    private fun read(): T = when (def) {
        is Boolean -> sp.getBoolean(key, def) as T
        is Int -> sp.getInt(key, def) as T
        is Float -> sp.getFloat(key, def) as T
        else -> (sp.getString(key, def as String) ?: def) as T
    }

    override fun getValue(thisRef: Any?, property: KProperty<*>): T = s.value

    override fun setValue(thisRef: Any?, property: KProperty<*>, value: T) {
        s.value = value
        sp.edit().apply {
            when (value) {
                is Boolean -> putBoolean(key, value)
                is Int -> putInt(key, value)
                is Float -> putFloat(key, value)
                else -> putString(key, value as String)
            }
        }.apply()
    }
}

class Settings private constructor(ctx: Context) {
    private val sp = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    // Vídeo
    var resScale by P(sp, "res_scale", 100)       // % da resolução da tela
    var bilinear by P(sp, "bilinear", false)
    var aspect by P(sp, "aspect", 0)              // 0 = 4:3, 1 = do núcleo, 2 = esticar
    var vsync by P(sp, "vsync", true)
    var showFps by P(sp, "show_fps", true)
    // Áudio
    var audioOn by P(sp, "audio_on", true)
    var audioSync by P(sp, "audio_sync", true)
    var volume by P(sp, "volume", 100)
    // Controles
    var showPad by P(sp, "show_pad", true)
    var padOpacity by P(sp, "pad_opacity", 0.6f)
    var padScale by P(sp, "pad_scale", 1.0f)
    var haptics by P(sp, "haptics", true)
    var analogPad by P(sp, "analog_pad", true)
    var padLayout by P(sp, "pad_layout", "")
    // Desempenho
    var profile by P(sp, "profile", 1)            // 0 desempenho, 1 equilibrado, 2 compatibilidade
    var fpsLimit by P(sp, "fps_limit", true)
    var frameskip by P(sp, "frameskip", 0)        // 0 desligado, 1 automático
    var enhance by P(sp, "enhance", false)        // resolução melhorada do núcleo (NEON)
    var cacheGames by P(sp, "cache_games", 1)
    // Biblioteca / BIOS
    var libraryUri by P(sp, "library_uri", "")
    var downloadCovers by P(sp, "dl_covers", true)
    var biosLabel by P(sp, "bios_label", "")

    fun applyProfile(p: Int) {
        profile = p
        when (p) {
            0 -> { frameskip = 1; enhance = false; bilinear = false; resScale = 75; vsync = true; fpsLimit = true }
            1 -> { frameskip = 0; enhance = false; bilinear = true; resScale = 100; fpsLimit = true }
            else -> { frameskip = 0; enhance = false; bilinear = false; resScale = 100; fpsLimit = true; audioSync = true }
        }
    }

    /** Opções repassadas ao núcleo PCSX-ReARMed (chaves desconhecidas são ignoradas; veja o logcat "ps1core"). */
    fun coreOptions(): Map<String, String> = mapOf(
        "pcsx_rearmed_frameskip_type" to if (frameskip > 0) "auto" else "disabled",
        "pcsx_rearmed_frameskip" to if (frameskip > 0) "1" else "0",
        "pcsx_rearmed_neon_enhancement_enable" to if (enhance) "enabled" else "disabled",
        "pcsx_rearmed_drc" to "enabled"
    )

    companion object {
        @Volatile private var inst: Settings? = null
        fun get(ctx: Context): Settings = inst ?: synchronized(this) {
            inst ?: Settings(ctx.applicationContext).also { inst = it }
        }
    }
}

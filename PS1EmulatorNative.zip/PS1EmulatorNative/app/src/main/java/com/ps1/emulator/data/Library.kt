package com.ps1.emulator.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.DocumentsContract
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class Game(
    val id: String,
    val title: String,
    val fileName: String,
    val uri: String,
    val extras: List<Pair<String, String>>,  // arquivos referenciados pelo CUE (nome, uri)
    val sizeBytes: Long,
    val serial: String?,
    val cover: String?,
    val lastPlayed: Long
)

class Library private constructor(private val ctx: Context) {
    var games by mutableStateOf<List<Game>>(emptyList())
        private set
    var scanning by mutableStateOf(false)
        private set
    var status by mutableStateOf("")
        private set

    private val file = File(ctx.filesDir, "library.json")
    private val coverDir = File(ctx.filesDir, "covers").apply { mkdirs() }

    val recent: List<Game> get() = games.filter { it.lastPlayed > 0 }.sortedByDescending { it.lastPlayed }.take(10)

    init { load() }

    private class Entry(val docId: String, val name: String, val mime: String, val size: Long, val uri: Uri) {
        val isDir get() = mime == DocumentsContract.Document.MIME_TYPE_DIR
    }

    // ---------- persistência ----------
    private fun load() {
        try {
            if (!file.exists()) return
            val arr = JSONArray(file.readText())
            games = (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val ex = o.optJSONArray("extras") ?: JSONArray()
                Game(
                    o.getString("id"), o.getString("title"), o.getString("file"), o.getString("uri"),
                    (0 until ex.length()).map { ex.getJSONObject(it).let { e -> e.getString("n") to e.getString("u") } },
                    o.optLong("size"), o.optString("serial").ifEmpty { null }, o.optString("cover").ifEmpty { null },
                    o.optLong("played")
                )
            }
        } catch (_: Exception) { games = emptyList() }
    }

    private fun save() {
        val arr = JSONArray()
        games.forEach { g ->
            arr.put(JSONObject().apply {
                put("id", g.id); put("title", g.title); put("file", g.fileName); put("uri", g.uri)
                put("size", g.sizeBytes); put("serial", g.serial ?: ""); put("cover", g.cover ?: ""); put("played", g.lastPlayed)
                put("extras", JSONArray().also { a -> g.extras.forEach { (n, u) -> a.put(JSONObject().put("n", n).put("u", u)) } })
            })
        }
        file.writeText(arr.toString())
    }

    fun markPlayed(id: String) {
        games = games.map { if (it.id == id) it.copy(lastPlayed = System.currentTimeMillis()) else it }
        save()
    }

    fun clear() {
        games = emptyList(); file.delete(); coverDir.deleteRecursively(); coverDir.mkdirs(); status = ""
    }

    // ---------- varredura ----------
    suspend fun scan(tree: Uri, downloadCovers: Boolean) = withContext(Dispatchers.IO) {
        scanning = true
        status = "Procurando jogos…"
        try {
            val found = ArrayList<Game>()
            val covers = HashMap<String, Uri>()
            walk(tree, DocumentsContract.getTreeDocumentId(tree), 0, found, covers)
            val old = games.associateBy { it.id }
            games = found.map { g ->
                val o = old[g.id]
                g.copy(
                    lastPlayed = o?.lastPlayed ?: 0L,
                    cover = o?.cover?.takeIf { File(it).exists() } ?: findLocalCover(g, covers)
                )
            }.sortedBy { it.title.lowercase() }
            save()
            if (downloadCovers) fetchOnlineCovers()
            status = "${games.size} jogo(s) na biblioteca"
        } catch (e: Exception) {
            status = "Erro ao ler a pasta: ${e.message}. Selecione a pasta novamente."
        } finally {
            scanning = false
        }
    }

    private fun children(tree: Uri, parentDocId: String): List<Entry> {
        val out = ArrayList<Entry>()
        val childUri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentDocId)
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE, DocumentsContract.Document.COLUMN_SIZE
        )
        ctx.contentResolver.query(childUri, cols, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0)
                out += Entry(id, c.getString(1) ?: "", c.getString(2) ?: "", c.getLong(3), DocumentsContract.buildDocumentUriUsingTree(tree, id))
            }
        }
        return out
    }

    private fun ext(n: String) = n.substringAfterLast('.', "").lowercase()
    private fun base(n: String) = n.substringBeforeLast('.')

    private fun walk(tree: Uri, docId: String, depth: Int, found: MutableList<Game>, covers: MutableMap<String, Uri>) {
        val list = children(tree, docId)
        val files = list.filter { !it.isDir }
        files.filter { ext(it.name) in setOf("jpg", "jpeg", "png", "webp") }.forEach { covers[base(it.name).lowercase()] = it.uri }
        val byName = files.associateBy { it.name.lowercase() }
        val hidden = HashSet<String>()

        for (cue in files.filter { ext(it.name) == "cue" }) {
            val refs = parseCue(cue.uri)
            refs.forEach { hidden += it.lowercase() }
            val extras = refs.mapNotNull { r -> byName[r.lowercase()]?.let { r to it.uri.toString() } }
            val extraSize = refs.sumOf { r -> byName[r.lowercase()]?.size ?: 0L }
            val serialSrc = refs.firstNotNullOfOrNull { r -> byName[r.lowercase()]?.uri }
            found += makeGame(cue, extras, extraSize, serialSrc)
        }
        for (f in files) {
            val e = ext(f.name)
            if (e in setOf("chd", "pbp", "iso", "img", "bin") && f.name.lowercase() !in hidden) {
                found += makeGame(f, emptyList(), 0L, if (e == "chd" || e == "pbp") null else f.uri)
            }
        }
        if (depth < 6) list.filter { it.isDir }.forEach { walk(tree, it.docId, depth + 1, found, covers) }
    }

    private fun parseCue(uri: Uri): List<String> = try {
        val text = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
        Regex("""(?i)FILE\s+(?:"([^"]*)"|(\S+))""").findAll(text)
            .map { (it.groups[1]?.value ?: it.groups[2]!!.value).substringAfterLast('/').substringAfterLast('\\') }
            .toList()
    } catch (_: Exception) { emptyList() }

    private fun makeGame(main: Entry, extras: List<Pair<String, String>>, extraSize: Long, serialSrc: Uri?): Game {
        val b = base(main.name)
        val clean = b.replace(Regex("""\s*[\(\[][^)\]]*[)\]]"""), "").trim().ifEmpty { b }
        return Game(
            id = Integer.toHexString(main.docId.hashCode()),
            title = clean, fileName = main.name, uri = main.uri.toString(), extras = extras,
            sizeBytes = main.size + extraSize, serial = serialSrc?.let { readSerial(it) },
            cover = null, lastPlayed = 0L
        )
    }

    /** Lê o código do disco (ex.: SLUS-00776) do SYSTEM.CNF nos primeiros MB da imagem. */
    private fun readSerial(uri: Uri): String? = try {
        ctx.contentResolver.openInputStream(uri)?.use { ins ->
            val buf = ByteArray(3 * 1024 * 1024)
            var n = 0
            while (n < buf.size) { val r = ins.read(buf, n, buf.size - n); if (r < 0) break; n += r }
            val m = Regex("""BOOT\s*=\s*cdrom:[\\/]*([A-Z]{4})_(\d{3})\.(\d{2})""").find(String(buf, 0, n, Charsets.ISO_8859_1))
            m?.let { "${it.groupValues[1]}-${it.groupValues[2]}${it.groupValues[3]}" }
        }
    } catch (_: Exception) { null }

    // ---------- capas ----------
    private fun findLocalCover(g: Game, covers: Map<String, Uri>): String? {
        val keys = listOfNotNull(g.serial?.lowercase(), base(g.fileName).lowercase(), g.title.lowercase())
        val uri = keys.firstNotNullOfOrNull { covers[it] } ?: return null
        return try {
            val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return null
            saveCover(bytes, File(coverDir, g.id + ".jpg"))
        } catch (_: Exception) { null }
    }

    private fun saveCover(bytes: ByteArray, dest: File): String? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var s = 1
        while (bounds.outWidth / (s * 2) >= 400 && bounds.outHeight / (s * 2) >= 400) s *= 2
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = s }) ?: return null
        dest.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }
        bmp.recycle()
        return dest.path
    }

    /** Busca capas em thumbnails.libretro.com pelo nome do arquivo (funciona quando o nome segue o padrão Redump/No-Intro). */
    private fun fetchOnlineCovers() {
        val missing = games.filter { it.cover == null }
        missing.forEachIndexed { i, g ->
            status = "Baixando capas (${i + 1}/${missing.size})…"
            val name = base(g.fileName).replace(Regex("[&*/:`<>?\\\\|]"), "_")
            val url = "https://thumbnails.libretro.com/Sony%20-%20PlayStation/Named_Boxarts/" +
                URLEncoder.encode(name, "UTF-8").replace("+", "%20") + ".png"
            try {
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 5000; c.readTimeout = 8000
                if (c.responseCode == 200) {
                    val bytes = c.inputStream.use { it.readBytes() }
                    saveCover(bytes, File(coverDir, g.id + ".jpg"))?.let { p ->
                        games = games.map { if (it.id == g.id) it.copy(cover = p) else it }
                    }
                }
                c.disconnect()
            } catch (_: Exception) { }
        }
        save()
    }

    companion object {
        @Volatile private var inst: Library? = null
        fun get(ctx: Context): Library = inst ?: synchronized(this) {
            inst ?: Library(ctx.applicationContext).also { inst = it }
        }
    }
}

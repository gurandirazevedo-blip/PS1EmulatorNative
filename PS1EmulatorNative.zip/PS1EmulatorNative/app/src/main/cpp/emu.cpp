// Frontend libretro nativo: carrega o núcleo PCSX-ReARMed (libpcsx_rearmed_libretro.so) com dlopen,
// roda o emulador em thread própria, renderiza com OpenGL ES 3 e toca áudio com AAudio.
#include <jni.h>
#include <android/log.h>
#include <dlfcn.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <GLES3/gl3.h>
#include <EGL/egl.h>
#include <aaudio/AAudio.h>
#include <atomic>
#include <chrono>
#include <cstdarg>
#include <cstdio>
#include <cstring>
#include <map>
#include <mutex>
#include <string>
#include <thread>
#include <vector>
#include "libretro_min.h"

#define TAG "ps1core"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

using Clock = std::chrono::steady_clock;

namespace {

struct CoreApi {
    void (*set_environment)(retro_environment_t);
    void (*set_video_refresh)(retro_video_refresh_t);
    void (*set_audio_sample)(retro_audio_sample_t);
    void (*set_audio_sample_batch)(retro_audio_sample_batch_t);
    void (*set_input_poll)(retro_input_poll_t);
    void (*set_input_state)(retro_input_state_t);
    void (*init)();
    void (*deinit)();
    unsigned (*api_version)();
    void (*get_system_info)(retro_system_info*);
    void (*get_system_av_info)(retro_system_av_info*);
    void (*set_controller_port_device)(unsigned, unsigned);
    void (*reset)();
    void (*run)();
    size_t (*serialize_size)();
    bool (*serialize)(void*, size_t);
    bool (*unserialize)(const void*, size_t);
    bool (*load_game)(const retro_game_info*);
    void (*unload_game)();
    void* (*get_memory_data)(unsigned);
    size_t (*get_memory_size)(unsigned);
};
CoreApi api;
void* g_core = nullptr;
bool g_inited = false, g_loaded = false;
std::string g_sysdir, g_savedir, g_err, g_ramPath;

std::mutex g_optMx;
std::map<std::string, std::string> g_opts;
std::map<std::string, bool> g_askedKeys;
std::atomic<bool> g_optsDirty{true};
std::mutex g_logMx;
std::string g_logTail;

std::atomic<bool> g_running{false}, g_paused{false};
std::thread g_thread;
std::atomic<int> g_tid{0};
std::atomic<uint32_t> g_mask{0};
std::atomic<int> g_lx{0}, g_ly{0}, g_rx{0}, g_ry{0};
std::atomic<bool> g_analog{true}, g_limit{true}, g_audioOn{true}, g_audioSync{true};
std::atomic<bool> g_bilinear{false}, g_vsync{true};
std::atomic<int> g_aspectMode{0}, g_volume{100};
std::atomic<float> g_speed{1.0f};
std::atomic<float> g_measFps{0}, g_runMs{0};
std::atomic<int> g_underruns{0};
std::atomic<float> g_aspect{4.f / 3.f};
double g_fps = 60.0;
retro_pixel_format g_fmt = RETRO_PIXEL_FORMAT_0RGB1555;  // padrão da especificação até o núcleo definir

std::mutex g_frameMx;
struct Frame { std::vector<uint8_t> buf; unsigned w = 0, h = 0; int fmt = 2; uint64_t seq = 0; } g_frame;

// ---------------- Áudio (AAudio + ring buffer SPSC) ----------------
constexpr size_t RING_FRAMES = 16384;
constexpr size_t RING_CAP = RING_FRAMES * 2;
int16_t g_ring[RING_CAP];
std::atomic<uint64_t> g_rw{0}, g_rr{0};
int g_rate = 44100;
AAudioStream* g_stream = nullptr;

size_t ring_used() { return (size_t)(g_rw.load(std::memory_order_acquire) - g_rr.load(std::memory_order_acquire)); }

void ring_write(const int16_t* d, size_t frames) {
    size_t n = frames * 2;
    if (RING_CAP - ring_used() < n) return;  // estouro: descarta
    uint64_t w = g_rw.load(std::memory_order_relaxed);
    int vol = g_volume.load();
    for (size_t i = 0; i < n; i++) {
        int s = d[i];
        if (vol != 100) s = s * vol / 100;
        g_ring[(w + i) % RING_CAP] = (int16_t)s;
    }
    g_rw.store(w + n, std::memory_order_release);
}

void ring_read(int16_t* out, size_t n) {
    size_t used = ring_used();
    size_t take = used < n ? used : n;
    uint64_t r = g_rr.load(std::memory_order_relaxed);
    for (size_t i = 0; i < take; i++) out[i] = g_ring[(r + i) % RING_CAP];
    for (size_t i = take; i < n; i++) out[i] = 0;
    if (take < n && g_running && !g_paused) g_underruns++;
    g_rr.store(r + take, std::memory_order_release);
}

aaudio_data_callback_result_t audio_data_cb(AAudioStream*, void*, void* audioData, int32_t numFrames) {
    ring_read((int16_t*)audioData, (size_t)numFrames * 2);
    return AAUDIO_CALLBACK_RESULT_CONTINUE;
}

void audio_close() {
    if (g_stream) {
        AAudioStream_requestStop(g_stream);
        AAudioStream_close(g_stream);
        g_stream = nullptr;
    }
}

bool audio_open(int rate) {
    audio_close();
    g_rate = rate > 8000 ? rate : 44100;
    g_rw = 0; g_rr = 0;
    AAudioStreamBuilder* b = nullptr;
    if (AAudio_createStreamBuilder(&b) != AAUDIO_OK) return false;
    AAudioStreamBuilder_setDirection(b, AAUDIO_DIRECTION_OUTPUT);
    AAudioStreamBuilder_setPerformanceMode(b, AAUDIO_PERFORMANCE_MODE_LOW_LATENCY);
    AAudioStreamBuilder_setSharingMode(b, AAUDIO_SHARING_MODE_SHARED);
    AAudioStreamBuilder_setSampleRate(b, g_rate);
    AAudioStreamBuilder_setChannelCount(b, 2);
    AAudioStreamBuilder_setFormat(b, AAUDIO_FORMAT_PCM_I16);
    AAudioStreamBuilder_setDataCallback(b, audio_data_cb, nullptr);
    aaudio_result_t r = AAudioStreamBuilder_openStream(b, &g_stream);
    AAudioStreamBuilder_delete(b);
    if (r != AAUDIO_OK) { g_stream = nullptr; LOGE("AAudio falhou: %s", AAudio_convertResultToText(r)); return false; }
    AAudioStream_setBufferSizeInFrames(g_stream, AAudioStream_getFramesPerBurst(g_stream) * 4);
    AAudioStream_requestStart(g_stream);
    return true;
}

// ---------------- Callbacks libretro ----------------
void add_log(const std::string& s) {
    std::lock_guard<std::mutex> l(g_logMx);
    g_logTail += s + "\n";
    if (g_logTail.size() > 6000) g_logTail.erase(0, g_logTail.size() - 6000);
}

void log_cb(retro_log_level lvl, const char* fmt, ...) {
    char buf[1024];
    va_list ap; va_start(ap, fmt); vsnprintf(buf, sizeof buf, fmt, ap); va_end(ap);
    int prio = lvl == RETRO_LOG_ERROR ? ANDROID_LOG_ERROR : lvl == RETRO_LOG_WARN ? ANDROID_LOG_WARN
             : lvl == RETRO_LOG_INFO ? ANDROID_LOG_INFO : ANDROID_LOG_DEBUG;
    __android_log_print(prio, TAG, "%s", buf);
    if (lvl >= RETRO_LOG_WARN) add_log(buf);
}

bool env_cb(unsigned cmd, void* data) {
    switch (cmd) {
        case RETRO_ENVIRONMENT_GET_CAN_DUPE: *(bool*)data = true; return true;
        case RETRO_ENVIRONMENT_SET_PIXEL_FORMAT: {
            auto f = *(retro_pixel_format*)data;
            if (f == RETRO_PIXEL_FORMAT_0RGB1555 || f == RETRO_PIXEL_FORMAT_XRGB8888 || f == RETRO_PIXEL_FORMAT_RGB565) { g_fmt = f; return true; }
            return false;
        }
        case RETRO_ENVIRONMENT_GET_SYSTEM_DIRECTORY:
        case RETRO_ENVIRONMENT_GET_CORE_ASSETS_DIRECTORY:
            *(const char**)data = g_sysdir.c_str(); return true;
        case RETRO_ENVIRONMENT_GET_SAVE_DIRECTORY: *(const char**)data = g_savedir.c_str(); return true;
        case RETRO_ENVIRONMENT_GET_LOG_INTERFACE: ((retro_log_callback*)data)->log = log_cb; return true;
        case RETRO_ENVIRONMENT_GET_VARIABLE: {
            auto* v = (retro_variable*)data;
            std::lock_guard<std::mutex> l(g_optMx);
            auto it = g_opts.find(v->key);
            if (g_askedKeys.find(v->key) == g_askedKeys.end()) {
                g_askedKeys[v->key] = true;
                LOGI("Opção solicitada: %s (%s)", v->key, it != g_opts.end() ? "definida pelo app" : "padrão do núcleo");
            }
            if (it != g_opts.end()) { v->value = it->second.c_str(); return true; }
            v->value = nullptr;
            return false;
        }
        case RETRO_ENVIRONMENT_GET_VARIABLE_UPDATE: *(bool*)data = g_optsDirty.exchange(false); return true;
        case RETRO_ENVIRONMENT_SET_VARIABLES: return true;
        case RETRO_ENVIRONMENT_SET_PERFORMANCE_LEVEL:
        case RETRO_ENVIRONMENT_SET_INPUT_DESCRIPTORS:
        case RETRO_ENVIRONMENT_SET_CONTROLLER_INFO:
        case RETRO_ENVIRONMENT_SET_SUPPORT_NO_GAME: return true;
        case RETRO_ENVIRONMENT_GET_INPUT_BITMASKS: return true;
        case RETRO_ENVIRONMENT_SET_MESSAGE: { auto* m = (retro_message*)data; if (m && m->msg) add_log(m->msg); return true; }
        case RETRO_ENVIRONMENT_SET_GEOMETRY: {
            auto* g = (retro_game_geometry*)data;
            float a = g->aspect_ratio;
            if (a <= 0.01f && g->base_height) a = (float)g->base_width / g->base_height;
            g_aspect = a; return true;
        }
        case RETRO_ENVIRONMENT_SET_SYSTEM_AV_INFO: {
            auto* av = (retro_system_av_info*)data;
            g_fps = av->timing.fps;
            float a = av->geometry.aspect_ratio;
            if (a <= 0.01f && av->geometry.base_height) a = (float)av->geometry.base_width / av->geometry.base_height;
            g_aspect = a;
            if ((int)av->timing.sample_rate != g_rate) audio_open((int)av->timing.sample_rate);
            return true;
        }
        default: return false;
    }
}

void video_cb(const void* data, unsigned w, unsigned h, size_t pitch) {
    if (!data || !w || !h) return;  // quadro repetido/pulado
    const bool is32 = g_fmt == RETRO_PIXEL_FORMAT_XRGB8888;
    const size_t row = (size_t)w * (is32 ? 4 : 2);
    std::lock_guard<std::mutex> l(g_frameMx);
    g_frame.buf.resize(row * h);
    g_frame.w = w; g_frame.h = h; g_frame.fmt = is32 ? 1 : 2;
    const uint8_t* src = (const uint8_t*)data;
    uint8_t* dst = g_frame.buf.data();
    if (g_fmt == RETRO_PIXEL_FORMAT_0RGB1555) {
        for (unsigned y = 0; y < h; y++) {
            const uint16_t* s = (const uint16_t*)(src + y * pitch);
            uint16_t* d = (uint16_t*)(dst + y * row);
            for (unsigned x = 0; x < w; x++) {
                uint16_t p = s[x];
                unsigned r = (p >> 10) & 31, g = (p >> 5) & 31, b = p & 31;
                d[x] = (uint16_t)((r << 11) | (g << 6) | ((g >> 4) << 5) | b);
            }
        }
    } else {
        for (unsigned y = 0; y < h; y++) memcpy(dst + y * row, src + y * pitch, row);
    }
    g_frame.seq++;
}

size_t audio_batch_cb(const int16_t* d, size_t frames) {
    if (g_audioOn && g_speed.load() <= 1.01f) ring_write(d, frames);
    return frames;
}
void audio_cb(int16_t l, int16_t r) { int16_t s[2] = {l, r}; audio_batch_cb(s, 1); }
void poll_cb() {}

int16_t input_cb(unsigned port, unsigned dev, unsigned idx, unsigned id) {
    if (port != 0) return 0;
    uint32_t m = g_mask.load();
    switch (dev & 0xff) {
        case RETRO_DEVICE_JOYPAD:
            if (id == RETRO_DEVICE_ID_JOYPAD_MASK) return (int16_t)(m & 0xFFFF);
            return id < 16 ? (int16_t)((m >> id) & 1) : 0;
        case RETRO_DEVICE_ANALOG:
            if (idx == 0) return (int16_t)(id == 0 ? g_lx.load() : id == 1 ? g_ly.load() : 0);
            if (idx == 1) return (int16_t)(id == 0 ? g_rx.load() : id == 1 ? g_ry.load() : 0);
            return 0;
        default: return 0;
    }
}

// ---------------- Memory card / estados / comandos ----------------
bool save_ram() {
    if (!api.get_memory_data || g_ramPath.empty()) return false;
    void* p = api.get_memory_data(RETRO_MEMORY_SAVE_RAM);
    size_t n = api.get_memory_size(RETRO_MEMORY_SAVE_RAM);
    if (!p || !n) return false;
    FILE* f = fopen(g_ramPath.c_str(), "wb");
    if (!f) return false;
    bool ok = fwrite(p, 1, n, f) == n;
    fclose(f);
    return ok;
}
void load_ram() {
    if (!api.get_memory_data || g_ramPath.empty()) return;
    void* p = api.get_memory_data(RETRO_MEMORY_SAVE_RAM);
    size_t n = api.get_memory_size(RETRO_MEMORY_SAVE_RAM);
    FILE* f = fopen(g_ramPath.c_str(), "rb");
    if (!f) return;
    if (p && n) { size_t r = fread(p, 1, n, f); (void)r; }
    fclose(f);
}

std::atomic<int> g_cmd{0};
std::atomic<bool> g_cmdOk{false};
std::string g_cmdPath;

bool run_cmd(int c, const std::string& path = "") {
    if (!g_running) return false;
    g_cmdPath = path; g_cmdOk = false; g_cmd = c;
    for (int i = 0; i < 5000 && g_cmd.load() != 0 && g_running; i++) usleep(1000);
    return g_cmdOk;
}

void handle_cmd() {
    int c = g_cmd.load();
    if (!c) return;
    bool ok = false;
    if (c == 1) {
        size_t sz = api.serialize_size();
        std::vector<uint8_t> b(sz);
        if (sz && api.serialize(b.data(), sz)) {
            FILE* f = fopen(g_cmdPath.c_str(), "wb");
            if (f) { ok = fwrite(b.data(), 1, sz, f) == sz; fclose(f); }
        }
    } else if (c == 2) {
        FILE* f = fopen(g_cmdPath.c_str(), "rb");
        if (f) {
            fseek(f, 0, SEEK_END); long n = ftell(f); rewind(f);
            if (n > 0) { std::vector<uint8_t> b((size_t)n); if (fread(b.data(), 1, (size_t)n, f) == (size_t)n) ok = api.unserialize(b.data(), (size_t)n); }
            fclose(f);
        }
    } else if (c == 3) { ok = save_ram(); }
    else if (c == 4) { api.reset(); ok = true; }
    g_cmdOk = ok;
    g_cmd = 0;
}

// ---------------- Loop de emulação ----------------
void emu_loop() {
    g_tid = (int)syscall(SYS_gettid);
    auto next = Clock::now();
    auto lastStat = next;
    int frames = 0;
    double ema = 0;
    while (g_running) {
        handle_cmd();
        if (g_paused) { usleep(15000); next = Clock::now(); lastStat = next; frames = 0; continue; }
        auto t0 = Clock::now();
        api.run();
        auto t1 = Clock::now();
        double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();
        ema = ema == 0 ? ms : ema * 0.9 + ms * 0.1;
        g_runMs = (float)ema;
        frames++;

        float speed = g_speed.load();
        if (g_audioSync && g_audioOn && g_stream && speed <= 1.01f) {
            const size_t high = (size_t)(g_rate * 0.08) * 2;  // ~80 ms
            for (int spins = 0; ring_used() > high && g_running && !g_paused && spins < 40; spins++) usleep(1000);
        }
        if (g_limit) {
            double fps = g_fps > 1.0 ? g_fps : 60.0;
            auto period = std::chrono::duration_cast<Clock::duration>(std::chrono::duration<double>(1.0 / (fps * speed)));
            next += period;
            auto now = Clock::now();
            if (next > now) std::this_thread::sleep_until(next);
            else if (now - next > std::chrono::milliseconds(100)) next = now;
        } else {
            next = Clock::now();
        }
        auto now = Clock::now();
        double dt = std::chrono::duration<double>(now - lastStat).count();
        if (dt >= 1.0) { g_measFps = (float)(frames / dt); frames = 0; lastStat = now; }
    }
}

// ---------------- Renderização OpenGL ES 3 ----------------
GLuint g_prog = 0, g_tex = 0, g_vbo = 0;
GLint g_locSwz = -1;
int g_sw = 1, g_sh = 1;
unsigned g_tw = 0, g_th = 0;
int g_tfmt = -1;
uint64_t g_upSeq = 0;
int g_vsyncApplied = -1;

const char* VS = "#version 300 es\n"
    "layout(location=0) in vec2 p; layout(location=1) in vec2 t; out vec2 uv;\n"
    "void main(){ uv=t; gl_Position=vec4(p,0.0,1.0); }\n";
const char* FS = "#version 300 es\nprecision mediump float;\n"
    "in vec2 uv; uniform sampler2D tex; uniform int swz; out vec4 c;\n"
    "void main(){ vec4 s=texture(tex,uv); c = swz==1 ? vec4(s.bgr,1.0) : vec4(s.rgb,1.0); }\n";

GLuint compile(GLenum type, const char* src) {
    GLuint s = glCreateShader(type);
    glShaderSource(s, 1, &src, nullptr);
    glCompileShader(s);
    GLint ok = 0; glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) { char b[512]; glGetShaderInfoLog(s, sizeof b, nullptr, b); LOGE("shader: %s", b); }
    return s;
}

std::string js(JNIEnv* e, jstring s) {
    const char* c = e->GetStringUTFChars(s, nullptr);
    std::string r(c ? c : "");
    if (c) e->ReleaseStringUTFChars(s, c);
    return r;
}

void reset_state() {
    g_mask = 0; g_lx = g_ly = g_rx = g_ry = 0;
    g_speed = 1.0f; g_measFps = 0; g_runMs = 0; g_underruns = 0; g_cmd = 0;
    g_fmt = RETRO_PIXEL_FORMAT_0RGB1555; g_fps = 60.0; g_aspect = 4.f / 3.f;
    { std::lock_guard<std::mutex> l(g_frameMx); g_frame.buf.clear(); g_frame.w = g_frame.h = 0; }
    { std::lock_guard<std::mutex> l(g_logMx); g_logTail.clear(); }
    { std::lock_guard<std::mutex> l(g_optMx); g_askedKeys.clear(); }
}

}  // namespace

// ======================= JNI =======================
#define JF(ret, name, ...) extern "C" JNIEXPORT ret JNICALL \
    Java_com_ps1_emulator_core_NativeBridge_##name(JNIEnv* env, jobject, ##__VA_ARGS__)

JF(jint, nativeInit, jstring coreDir, jstring sysDir, jstring saveDir) {
    reset_state();
    std::string cdir = js(env, coreDir);
    g_sysdir = js(env, sysDir);
    g_savedir = js(env, saveDir);
    g_err.clear();
    std::string p = cdir + "/libpcsx_rearmed_libretro.so";
    g_core = dlopen(p.c_str(), RTLD_NOW | RTLD_LOCAL);
    if (!g_core) g_core = dlopen("libpcsx_rearmed_libretro.so", RTLD_NOW | RTLD_LOCAL);
    if (!g_core) { const char* e = dlerror(); g_err = e ? e : "dlopen falhou"; return -1; }
#define LOAD(f, n) api.f = (decltype(api.f))dlsym(g_core, n); \
    if (!api.f) { g_err = std::string("símbolo ausente: ") + n; return -2; }
    LOAD(set_environment, "retro_set_environment")
    LOAD(set_video_refresh, "retro_set_video_refresh")
    LOAD(set_audio_sample, "retro_set_audio_sample")
    LOAD(set_audio_sample_batch, "retro_set_audio_sample_batch")
    LOAD(set_input_poll, "retro_set_input_poll")
    LOAD(set_input_state, "retro_set_input_state")
    LOAD(init, "retro_init")
    LOAD(deinit, "retro_deinit")
    LOAD(api_version, "retro_api_version")
    LOAD(get_system_info, "retro_get_system_info")
    LOAD(get_system_av_info, "retro_get_system_av_info")
    LOAD(set_controller_port_device, "retro_set_controller_port_device")
    LOAD(reset, "retro_reset")
    LOAD(run, "retro_run")
    LOAD(serialize_size, "retro_serialize_size")
    LOAD(serialize, "retro_serialize")
    LOAD(unserialize, "retro_unserialize")
    LOAD(load_game, "retro_load_game")
    LOAD(unload_game, "retro_unload_game")
    LOAD(get_memory_data, "retro_get_memory_data")
    LOAD(get_memory_size, "retro_get_memory_size")
#undef LOAD
    if (api.api_version() != RETRO_API_VERSION) { g_err = "versão da API libretro incompatível"; return -3; }
    api.set_environment(env_cb);
    api.set_video_refresh(video_cb);
    api.set_audio_sample(audio_cb);
    api.set_audio_sample_batch(audio_batch_cb);
    api.set_input_poll(poll_cb);
    api.set_input_state(input_cb);
    g_optsDirty = true;
    api.init();
    g_inited = true;
    return 0;
}

JF(void, nativeSetOption, jstring key, jstring value) {
    std::lock_guard<std::mutex> l(g_optMx);
    g_opts[js(env, key)] = js(env, value);
    g_optsDirty = true;
}

JF(void, nativeSetConfig, jboolean limit, jboolean audioOn, jboolean audioSync, jint volume,
   jboolean bilinear, jint aspectMode, jboolean vsync, jboolean analog) {
    g_limit = limit; g_audioOn = audioOn; g_audioSync = audioSync;
    g_volume = volume < 0 ? 0 : volume > 100 ? 100 : volume;
    g_bilinear = bilinear; g_aspectMode = aspectMode; g_vsync = vsync; g_analog = analog;
}

JF(jboolean, nativeLoadGame, jstring path, jstring ramPath) {
    if (!g_inited) { g_err = "núcleo não inicializado"; return JNI_FALSE; }
    std::string gp = js(env, path);
    g_ramPath = js(env, ramPath);
    retro_system_info si{};
    api.get_system_info(&si);
    retro_game_info gi{};
    gi.path = gp.c_str();
    std::vector<char> data;
    if (!si.need_fullpath) {
        FILE* f = fopen(gp.c_str(), "rb");
        if (!f) { g_err = "não foi possível abrir o arquivo do jogo"; return JNI_FALSE; }
        fseek(f, 0, SEEK_END); long n = ftell(f); rewind(f);
        data.resize((size_t)n);
        size_t r = fread(data.data(), 1, (size_t)n, f); (void)r;
        fclose(f);
        gi.data = data.data(); gi.size = data.size();
    }
    if (!api.load_game(&gi)) {
        std::lock_guard<std::mutex> l(g_logMx);
        g_err = "retro_load_game falhou. " + g_logTail;
        return JNI_FALSE;
    }
    g_loaded = true;
    retro_system_av_info av{};
    api.get_system_av_info(&av);
    g_fps = av.timing.fps > 1.0 ? av.timing.fps : 60.0;
    float a = av.geometry.aspect_ratio;
    if (a <= 0.01f && av.geometry.base_height) a = (float)av.geometry.base_width / av.geometry.base_height;
    g_aspect = a;
    if (g_audioOn) audio_open((int)av.timing.sample_rate);
    api.set_controller_port_device(0, g_analog ? RETRO_DEVICE_ANALOG : RETRO_DEVICE_JOYPAD);
    load_ram();
    return JNI_TRUE;
}

JF(void, nativeStart) {
    if (g_running || !g_loaded) return;
    g_paused = false;
    g_running = true;
    g_thread = std::thread(emu_loop);
}

JF(void, nativePause, jboolean p) { g_paused = p; }

JF(void, nativeStop) {
    g_running = false;
    if (g_thread.joinable()) g_thread.join();
    if (g_inited) {
        if (g_loaded) { save_ram(); api.unload_game(); g_loaded = false; }
        api.deinit();
        g_inited = false;
    }
    audio_close();
    if (g_core) { dlclose(g_core); g_core = nullptr; }
    g_mask = 0;
}

JF(void, nativeSetInput, jint mask, jint lx, jint ly, jint rx, jint ry) {
    g_mask = (uint32_t)mask; g_lx = lx; g_ly = ly; g_rx = rx; g_ry = ry;
}

JF(void, nativeSetSpeed, jfloat s) { g_speed = s < 0.25f ? 0.25f : s > 8.f ? 8.f : s; }

JF(jfloatArray, nativeGetStats) {
    float v[4] = { g_measFps.load(), g_runMs.load(), (float)g_underruns.load(), (float)(ring_used() / 2) * 1000.f / (float)g_rate };
    jfloatArray arr = env->NewFloatArray(4);
    env->SetFloatArrayRegion(arr, 0, 4, v);
    return arr;
}

JF(jstring, nativeLastError) {
    std::string s = g_err;
    { std::lock_guard<std::mutex> l(g_logMx); if (!g_logTail.empty()) s += "\n" + g_logTail; }
    return env->NewStringUTF(s.c_str());
}

JF(jboolean, nativeSaveState, jstring path) { return run_cmd(1, js(env, path)) ? JNI_TRUE : JNI_FALSE; }
JF(jboolean, nativeLoadState, jstring path) { return run_cmd(2, js(env, path)) ? JNI_TRUE : JNI_FALSE; }
JF(jboolean, nativeFlushRam) { return run_cmd(3) ? JNI_TRUE : JNI_FALSE; }
JF(jboolean, nativeReset) { return run_cmd(4) ? JNI_TRUE : JNI_FALSE; }
JF(jint, nativeEmuTid) { return g_tid.load(); }

JF(jstring, nativeSurfaceCreated) {
    GLuint vs = compile(GL_VERTEX_SHADER, VS), fs = compile(GL_FRAGMENT_SHADER, FS);
    g_prog = glCreateProgram();
    glAttachShader(g_prog, vs); glAttachShader(g_prog, fs);
    glLinkProgram(g_prog);
    glDeleteShader(vs); glDeleteShader(fs);
    g_locSwz = glGetUniformLocation(g_prog, "swz");
    glGenTextures(1, &g_tex);
    glGenBuffers(1, &g_vbo);
    g_tw = g_th = 0; g_tfmt = -1; g_upSeq = 0; g_vsyncApplied = -1;
    const char* r = (const char*)glGetString(GL_RENDERER);
    return env->NewStringUTF(r ? r : "desconhecida");
}

JF(void, nativeSurfaceChanged, jint w, jint h) { g_sw = w > 0 ? w : 1; g_sh = h > 0 ? h : 1; }

JF(void, nativeDrawFrame) {
    glViewport(0, 0, g_sw, g_sh);
    glClearColor(0.f, 0.f, 0.f, 1.f);
    glClear(GL_COLOR_BUFFER_BIT);
    int vs = g_vsync.load() ? 1 : 0;
    if (g_vsyncApplied != vs) { eglSwapInterval(eglGetCurrentDisplay(), vs); g_vsyncApplied = vs; }
    {
        std::lock_guard<std::mutex> l(g_frameMx);
        if (g_frame.seq != g_upSeq && !g_frame.buf.empty()) {
            glBindTexture(GL_TEXTURE_2D, g_tex);
            glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
            bool full = g_tw != g_frame.w || g_th != g_frame.h || g_tfmt != g_frame.fmt;
            if (g_frame.fmt == 1) {
                if (full) glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, g_frame.w, g_frame.h, 0, GL_RGBA, GL_UNSIGNED_BYTE, g_frame.buf.data());
                else glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, g_frame.w, g_frame.h, GL_RGBA, GL_UNSIGNED_BYTE, g_frame.buf.data());
            } else {
                if (full) glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, g_frame.w, g_frame.h, 0, GL_RGB, GL_UNSIGNED_SHORT_5_6_5, g_frame.buf.data());
                else glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, g_frame.w, g_frame.h, GL_RGB, GL_UNSIGNED_SHORT_5_6_5, g_frame.buf.data());
            }
            g_tw = g_frame.w; g_th = g_frame.h; g_tfmt = g_frame.fmt; g_upSeq = g_frame.seq;
        }
    }
    if (!g_tw) return;

    float x = 1.f, y = 1.f;
    int mode = g_aspectMode.load();
    if (mode != 2) {
        float A = mode == 0 ? 4.f / 3.f : (g_aspect.load() > 0.1f ? g_aspect.load() : (float)g_tw / (float)g_th);
        float sa = (float)g_sw / (float)g_sh;
        if (sa > A) { y = 1.f; x = A / sa; } else { x = 1.f; y = sa / A; }
    }
    float v[16] = { -x, y, 0.f, 0.f,   x, y, 1.f, 0.f,   -x, -y, 0.f, 1.f,   x, -y, 1.f, 1.f };
    glUseProgram(g_prog);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, g_tex);
    GLint filt = g_bilinear.load() ? GL_LINEAR : GL_NEAREST;
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, filt);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, filt);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glUniform1i(g_locSwz, g_tfmt == 1 ? 1 : 0);
    glBindBuffer(GL_ARRAY_BUFFER, g_vbo);
    glBufferData(GL_ARRAY_BUFFER, sizeof(v), v, GL_DYNAMIC_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 16, (void*)0);
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 16, (void*)8);
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
}

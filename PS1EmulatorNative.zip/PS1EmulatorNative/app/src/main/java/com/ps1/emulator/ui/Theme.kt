package com.ps1.emulator.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

val Bg = Color(0xFF0D1117)
val Panel = Color(0xFF161B22)
val Accent = Color(0xFF4C8DFF)

private val scheme = darkColorScheme(
    primary = Accent, onPrimary = Color.White,
    background = Bg, onBackground = Color(0xFFE6EDF3),
    surface = Panel, onSurface = Color(0xFFE6EDF3),
    surfaceVariant = Color(0xFF21262D), onSurfaceVariant = Color(0xFF9DA7B3),
    secondaryContainer = Color(0xFF1F3A66), onSecondaryContainer = Color.White
)

@Composable
fun PS1Theme(content: @Composable () -> Unit) = MaterialTheme(colorScheme = scheme, content = content)

/** Cache de capas limitado a 1/8 da memória do app (controle de consumo de memória). */
object CoverCache {
    private val lru = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 8).toInt().coerceAtLeast(1 shl 20)) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }

    suspend fun load(path: String): Bitmap? {
        lru.get(path)?.let { return it }
        return withContext(Dispatchers.IO) {
            val bmp = try { BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = 1 }) } catch (_: Throwable) { null }
            if (bmp != null) lru.put(path, bmp)
            bmp
        }
    }

    fun trim() = lru.evictAll()
}

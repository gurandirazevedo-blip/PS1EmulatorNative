package com.ps1.emulator.core

import android.content.Context
import java.io.File

/** Ponte JNI para o frontend libretro em C++ (libps1native.so). */
object NativeBridge {
    init { System.loadLibrary("ps1native") }

    external fun nativeInit(coreDir: String, sysDir: String, saveDir: String): Int
    external fun nativeSetOption(key: String, value: String)
    external fun nativeSetConfig(
        limit: Boolean, audioOn: Boolean, audioSync: Boolean, volume: Int,
        bilinear: Boolean, aspectMode: Int, vsync: Boolean, analog: Boolean
    )
    external fun nativeLoadGame(path: String, ramPath: String): Boolean
    external fun nativeStart()
    external fun nativePause(p: Boolean)
    external fun nativeStop()
    external fun nativeSetInput(mask: Int, lx: Int, ly: Int, rx: Int, ry: Int)
    external fun nativeSetSpeed(s: Float)
    external fun nativeGetStats(): FloatArray
    external fun nativeLastError(): String
    external fun nativeSaveState(path: String): Boolean
    external fun nativeLoadState(path: String): Boolean
    external fun nativeFlushRam(): Boolean
    external fun nativeReset(): Boolean
    external fun nativeEmuTid(): Int
    external fun nativeSurfaceCreated(): String
    external fun nativeSurfaceChanged(w: Int, h: Int)
    external fun nativeDrawFrame()
}

object CoreInfo {
    fun file(ctx: Context) = File(ctx.applicationInfo.nativeLibraryDir, "libpcsx_rearmed_libretro.so")
    fun available(ctx: Context) = file(ctx).exists()
}

package com.ps1.emulator.data

import android.content.Context
import android.net.Uri
import java.io.File
import java.io.IOException

/**
 * O núcleo precisa de caminhos de arquivo reais (não content://). Copiamos o jogo (e as faixas do CUE)
 * para o armazenamento do app, mantendo apenas os últimos N jogos preparados.
 */
object GameStager {
    fun root(ctx: Context) = File(ctx.filesDir, "games").apply { mkdirs() }
    fun clear(ctx: Context) { root(ctx).deleteRecursively() }
    fun cacheBytes(ctx: Context): Long = root(ctx).walkTopDown().filter { it.isFile }.sumOf { it.length() }

    private fun sizeOf(ctx: Context, uri: Uri): Long = try {
        ctx.contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: 0L
    } catch (_: Exception) { 0L }

    fun stage(ctx: Context, g: Game, keep: Int, onProgress: (Float) -> Unit): File {
        val dir = File(root(ctx), g.id).apply { mkdirs() }
        val parts = listOf(g.fileName to g.uri) + g.extras
        val sizes = parts.map { sizeOf(ctx, Uri.parse(it.second)).coerceAtLeast(0L) }
        val total = sizes.sum().coerceAtLeast(1L)
        val need = parts.indices.sumOf { i ->
            val f = File(dir, parts[i].first)
            if (f.exists() && f.length() == sizes[i]) 0L else sizes[i]
        }
        if (dir.usableSpace < need + 64L * 1024 * 1024) {
            throw IOException("Espaço insuficiente no armazenamento (necessário ~${need / 1048576} MB).")
        }
        var done = 0L
        parts.forEachIndexed { i, (name, uriStr) ->
            val uri = Uri.parse(uriStr)
            val dest = File(dir, name)
            when {
                name.endsWith(".cue", true) -> { writeCue(ctx, uri, dest); done += sizes[i] }
                dest.exists() && sizes[i] > 0 && dest.length() == sizes[i] -> done += sizes[i]
                else -> {
                    ctx.contentResolver.openInputStream(uri)!!.use { ins ->
                        dest.outputStream().use { out ->
                            val buf = ByteArray(1 shl 20)
                            while (true) {
                                val r = ins.read(buf)
                                if (r < 0) break
                                out.write(buf, 0, r)
                                done += r
                                onProgress(done.toFloat() / total)
                            }
                        }
                    }
                }
            }
            onProgress(done.toFloat() / total)
        }
        dir.setLastModified(System.currentTimeMillis())
        prune(ctx, g.id, keep)
        return File(dir, g.fileName)
    }

    /** Reescreve o CUE para referenciar apenas nomes de arquivo (sem subpastas). */
    private fun writeCue(ctx: Context, src: Uri, dest: File) {
        val text = ctx.contentResolver.openInputStream(src)!!.bufferedReader().use { it.readText() }
        val fixed = Regex("""(?i)FILE\s+(?:"([^"]*)"|(\S+))""").replace(text) { m ->
            val n = (m.groups[1]?.value ?: m.groups[2]!!.value).substringAfterLast('/').substringAfterLast('\\')
            "FILE \"$n\""
        }
        dest.writeText(fixed)
    }

    private fun prune(ctx: Context, currentId: String, keep: Int) {
        val others = root(ctx).listFiles { f -> f.isDirectory && f.name != currentId }?.sortedByDescending { it.lastModified() } ?: return
        others.drop((keep - 1).coerceAtLeast(0)).forEach { it.deleteRecursively() }
    }
}

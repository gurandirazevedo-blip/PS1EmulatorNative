package com.ps1.emulator.data

import android.content.Context
import android.net.Uri
import java.io.File
import java.security.MessageDigest

/** Importa a BIOS pessoal do usuário. Nenhuma BIOS é distribuída com o app. */
object BiosManager {
    const val SIZE = 512 * 1024

    data class Info(val ok: Boolean, val label: String)

    // MD5 de dumps conhecidos -> (nome que o núcleo procura, descrição)
    private val KNOWN = mapOf(
        "924e392ed05558ffdb115408c263dccf" to ("scph1001.bin" to "SCPH-1001 (EUA v2.0)"),
        "54847e693405ffeb0359c6287434cbef" to ("scph1002.bin" to "SCPH-1002 (Europa v2.0)"),
        "8dd7d5296a650fac7319bce665a6a53c" to ("scph5500.bin" to "SCPH-5500 (Japão v3.0)"),
        "490f666e1afb15b7362b406ed1cea246" to ("scph5501.bin" to "SCPH-5501 (EUA v3.0)"),
        "32736f17079d0b2b7024407c39bd3050" to ("scph5502.bin" to "SCPH-5502 (Europa v3.0)"),
        "1e68c231d0896b7eadcad1d7d8e76129" to ("scph7001.bin" to "SCPH-7001 (EUA v4.1)")
    )

    fun dir(ctx: Context): File = File(ctx.filesDir, "system").apply { mkdirs() }

    fun current(ctx: Context): Info {
        val f = dir(ctx).listFiles()?.firstOrNull { it.isFile && it.length() == SIZE.toLong() }
            ?: return Info(false, "BIOS não importada")
        val label = Settings.get(ctx).biosLabel
        return Info(true, label.ifEmpty { f.name })
    }

    fun import(ctx: Context, uri: Uri): Result<String> = runCatching {
        val buf = ByteArray(SIZE + 1)
        var n = 0
        ctx.contentResolver.openInputStream(uri)!!.use { ins ->
            while (n < buf.size) {
                val r = ins.read(buf, n, buf.size - n)
                if (r < 0) break
                n += r
            }
        }
        require(n == SIZE) { "Tamanho inválido: uma BIOS de PS1 tem exatamente 512 KB (arquivo com ${if (n > SIZE) "mais de 512" else (n / 1024).toString()} KB)." }
        val data = buf.copyOf(SIZE)
        require(data.any { it != 0.toByte() } && data.any { it != 0xFF.toByte() }) { "Arquivo vazio ou corrompido." }
        val md5 = MessageDigest.getInstance("MD5").digest(data).joinToString("") { "%02x".format(it) }
        val known = KNOWN[md5]
        val name = known?.first ?: "scph5501.bin"
        val label = known?.second ?: "BIOS personalizada (tamanho válido, versão não reconhecida)"
        dir(ctx).listFiles()?.forEach { it.delete() }
        File(dir(ctx), name).writeBytes(data)
        Settings.get(ctx).biosLabel = label
        label
    }
}

@file:OptIn(ExperimentalMaterial3Api::class)

package com.ps1.emulator.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ps1.emulator.data.BiosManager
import com.ps1.emulator.data.Game
import com.ps1.emulator.data.Library

@Composable
fun Cover(game: Game, modifier: Modifier) {
    val bmp by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, game.cover) {
        value = game.cover?.let { CoverCache.load(it)?.asImageBitmap() }
    }
    Box(
        modifier.background(Brush.linearGradient(listOf(Color(0xFF283593), Color(0xFF00897B)))),
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) {
            Image(b, game.title, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Text(
                game.title.split(" ").filter { it.isNotEmpty() }.take(2).joinToString("") { it.first().uppercase() },
                fontSize = 34.sp, fontWeight = FontWeight.Bold, color = Color.White.copy(alpha = 0.85f)
            )
        }
    }
}

@Composable
private fun GameCard(g: Game, selected: Boolean, onClick: () -> Unit) {
    Column(Modifier.clickable(onClick = onClick)) {
        Cover(
            g,
            Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(12.dp))
                .then(if (selected) Modifier.background(Accent) else Modifier)
                .padding(if (selected) 3.dp else 0.dp).clip(RoundedCornerShape(10.dp))
        )
        Text(
            g.title, Modifier.padding(top = 6.dp), maxLines = 2, overflow = TextOverflow.Ellipsis,
            fontSize = 13.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
        )
        g.serial?.let { Text(it, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}

@Composable
fun HomeScreen(
    lib: Library,
    bios: BiosManager.Info,
    coreOk: Boolean,
    selected: String?,
    onSelect: (String) -> Unit,
    onImportGames: () -> Unit,
    onImportBios: () -> Unit,
    onPlay: (Game) -> Unit,
    onSettings: () -> Unit
) {
    val selectedGame = lib.games.firstOrNull { it.id == selected }
    Scaffold(
        containerColor = Bg,
        topBar = {
            TopAppBar(
                title = { Text("PS1 Emulator Native", fontWeight = FontWeight.Bold) },
                actions = { IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, "Configurações") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Bg, titleContentColor = Color.White, actionIconContentColor = Color.White)
            )
        },
        bottomBar = {
            if (selectedGame != null) {
                Surface(color = Panel, tonalElevation = 6.dp) {
                    Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Cover(selectedGame, Modifier.size(48.dp).clip(RoundedCornerShape(8.dp)))
                        Text(selectedGame.title, Modifier.weight(1f).padding(horizontal = 12.dp), maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                        Button(onClick = { onPlay(selectedGame) }) {
                            Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text("JOGAR", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    ) { pad ->
        LazyVerticalGrid(
            columns = GridCells.Adaptive(130.dp),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.padding(pad).fillMaxSize()
        ) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = onImportGames, Modifier.weight(1f)) { Text("IMPORTAR JOGOS", fontWeight = FontWeight.Bold, fontSize = 13.sp) }
                        OutlinedButton(onClick = onImportBios, Modifier.weight(1f)) { Text("IMPORTAR BIOS", fontWeight = FontWeight.Bold, fontSize = 13.sp) }
                    }
                    if (!coreOk) {
                        StatusCard("Núcleo de emulação ausente no APK. Siga o README (scripts/fetch_core.sh) e recompile.", true)
                    }
                    StatusCard(if (bios.ok) "BIOS: ${bios.label}" else "BIOS não importada — toque em IMPORTAR BIOS e escolha seu arquivo.", !bios.ok)
                    if (lib.scanning) {
                        LinearProgressIndicator(Modifier.fillMaxWidth())
                    }
                    if (lib.status.isNotEmpty()) Text(lib.status, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            if (lib.recent.isNotEmpty()) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Column {
                        Text("Recentes", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(bottom = 8.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(lib.recent, key = { it.id }) { g ->
                                Column(Modifier.width(96.dp).clickable { onSelect(g.id) }) {
                                    Cover(g, Modifier.size(96.dp).clip(RoundedCornerShape(10.dp)))
                                    Text(g.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
            item(span = { GridItemSpan(maxLineSpan) }) {
                Text("Jogos (${lib.games.size})", style = MaterialTheme.typography.titleMedium)
            }
            if (lib.games.isEmpty() && !lib.scanning) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Como começar", fontWeight = FontWeight.Bold)
                            Text("1. Toque em IMPORTAR JOGOS e escolha a pasta com seus jogos (BIN/CUE, ISO, CHD ou PBP).")
                            Text("2. Toque em IMPORTAR BIOS e escolha o arquivo da sua BIOS de PS1 (512 KB).")
                            Text("3. Toque em um jogo e depois em JOGAR.")
                        }
                    }
                }
            }
            items(lib.games, key = { it.id }) { g -> GameCard(g, g.id == selected) { onSelect(g.id) } }
        }
    }
}

@Composable
private fun StatusCard(text: String, warn: Boolean) {
    Surface(
        shape = RoundedCornerShape(10.dp), color = Panel,
        border = BorderStroke(1.dp, if (warn) Color(0xFFE5A100) else Color(0xFF2EA043))
    ) { Text(text, Modifier.fillMaxWidth().padding(12.dp), fontSize = 13.sp) }
}

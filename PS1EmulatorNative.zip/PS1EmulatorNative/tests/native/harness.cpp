#include <jni.h>
#include <dlfcn.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <string>
#define N(n) Java_com_ps1_emulator_core_NativeBridge_##n
extern "C" {
jint N(nativeInit)(JNIEnv*, jobject, jstring, jstring, jstring);
void N(nativeSetOption)(JNIEnv*, jobject, jstring, jstring);
void N(nativeSetConfig)(JNIEnv*, jobject, jboolean, jboolean, jboolean, jint, jboolean, jint, jboolean, jboolean);
jboolean N(nativeLoadGame)(JNIEnv*, jobject, jstring, jstring);
void N(nativeStart)(JNIEnv*, jobject); void N(nativePause)(JNIEnv*, jobject, jboolean); void N(nativeStop)(JNIEnv*, jobject);
void N(nativeSetInput)(JNIEnv*, jobject, jint, jint, jint, jint, jint);
jfloatArray N(nativeGetStats)(JNIEnv*, jobject);
jboolean N(nativeSaveState)(JNIEnv*, jobject, jstring); jboolean N(nativeLoadState)(JNIEnv*, jobject, jstring);
jboolean N(nativeFlushRam)(JNIEnv*, jobject); jboolean N(nativeReset)(JNIEnv*, jobject);
jstring N(nativeSurfaceCreated)(JNIEnv*, jobject); void N(nativeSurfaceChanged)(JNIEnv*, jobject, jint, jint); void N(nativeDrawFrame)(JNIEnv*, jobject);
}
static int fails = 0;
#define CHECK(c, msg) do { bool ok=(c); printf("%s  %s\n", ok?"PASS":"FAIL", msg); if(!ok) fails++; } while(0)
int main(int argc, char** argv) {
  JNIEnv* e = nullptr; jobject o = nullptr;
  const char* dir = argv[1]; (void)argc;
  N(nativeSetOption)(e,o,(jstring)"pcsx_rearmed_drc",(jstring)"enabled");
  CHECK(N(nativeInit)(e,o,(jstring)dir,(jstring)"/tmp/t",(jstring)"/tmp/t")==0, "nativeInit: dlopen + 21 símbolos libretro");
  N(nativeSetConfig)(e,o,1,1,1,100,0,0,1,1);
  CHECK(!N(nativeLoadGame)(e,o,(jstring)"/tmp/t/outro.bin",(jstring)"/tmp/t/x.mcr"), "retro_load_game rejeita jogo inválido (retorna false)");
  CHECK(N(nativeLoadGame)(e,o,(jstring)"/tmp/t/test.cue",(jstring)"/tmp/t/test.mcr"), "nativeLoadGame com test.cue");
  N(nativeStart)(e,o);
  N(nativeSetInput)(e,o,(1<<0)|(1<<9),0,0,0,0);   // ✕ + △
  usleep(1500000);
  float* s = (float*)N(nativeGetStats)(e,o);
  printf("     stats: fps=%.1f run=%.3fms underruns=%.0f\n", s[0], s[1], s[2]);
  CHECK(s[0] > 50 && s[0] < 70, "loop de emulação limitado a ~60 FPS");
  void* h = dlopen(( std::string(dir) + "/libpcsx_rearmed_libretro.so").c_str(), RTLD_NOW|RTLD_NOLOAD);
  void (*fs)(int*) = (void(*)(int*))dlsym(h, "fake_stats");
  int st[4]; fs(st);
  CHECK(st[0] > 60, "núcleo executou retro_run repetidamente");
  CHECK(st[1] == ((1<<0)|(1<<9)), "entrada (máscara X+△) chegou ao núcleo via input_state(MASK)");
  CHECK(st[2] == 1, "opção do app entregue ao núcleo via GET_VARIABLE");
  CHECK(N(nativeSaveState)(e,o,(jstring)"/tmp/t/s1.state"), "save state (retro_serialize)");
  int before=st[0]; usleep(300000);
  CHECK(N(nativeLoadState)(e,o,(jstring)"/tmp/t/s1.state"), "load state (retro_unserialize)");
  CHECK(N(nativeFlushRam)(e,o) && access("/tmp/t/test.mcr",F_OK)==0, "memory card gravado em disco");
  CHECK(N(nativeReset)(e,o), "retro_reset");
  N(nativePause)(e,o,1); usleep(200000); fs(st); int p1=st[0]; usleep(300000); fs(st);
  CHECK(st[0]==p1, "pausa interrompe o retro_run"); N(nativePause)(e,o,0);
  jstring g = N(nativeSurfaceCreated)(e,o); N(nativeSurfaceChanged)(e,o,1280,720);
  for(int i=0;i<5;i++) N(nativeDrawFrame)(e,o);
  CHECK(strcmp((const char*)g,"Stub GPU")==0, "renderer GL: surfaceCreated/Changed/DrawFrame executam sem travar");
  (void)before;
  N(nativeStop)(e,o);
  CHECK(access("/tmp/t/test.mcr",F_OK)==0, "nativeStop (join, save_ram, deinit, dlclose)");
  printf(fails? "\n%d FALHA(S)\n":"\nTODOS OS TESTES PASSARAM\n", fails);
  return fails;
}

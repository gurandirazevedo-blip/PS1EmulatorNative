#!/usr/bin/env bash
exec bash "$(dirname "$0")/build_core.sh"
